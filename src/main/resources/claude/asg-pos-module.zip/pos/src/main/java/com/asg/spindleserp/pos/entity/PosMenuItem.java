package com.asg.spindleserp.pos.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "pos_menu_items",
        uniqueConstraints = @UniqueConstraint(name = "uq_pos_item_org_code", columnNames = {"organization_id", "item_code"}),
        indexes = {
                @Index(name = "idx_pos_item_org", columnList = "organization_id"),
                @Index(name = "idx_pos_item_cat", columnList = "category_id"),
                @Index(name = "idx_pos_item_avail", columnList = "available")
        })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosMenuItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "organization_id", nullable = false)
    private Long organizationId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private PosCategory category;

    @Column(name = "item_code", length = 30)
    private String itemCode;

    @Column(name = "item_name", nullable = false, length = 150)
    private String itemName;

    @Column(columnDefinition = "text")
    private String description;

    @Builder.Default
    @Column(name = "unit_price", nullable = false, precision = 14, scale = 2)
    private BigDecimal unitPrice = BigDecimal.ZERO;

    @Builder.Default
    @Column(name = "stock_qty", nullable = false, precision = 12, scale = 2)
    private BigDecimal stockQty = BigDecimal.ZERO;

    /** Some menu items (e.g. made-to-order dishes) don't track finite stock. */
    @Builder.Default
    @Column(name = "track_stock", nullable = false)
    private boolean trackStock = true;

    @Builder.Default
    @Column(nullable = false)
    private boolean available = true;

    @Column(name = "image_url", length = 500)
    private String imageUrl;

    /** ★ optional bridge to inv_items.id — nullable, not FK-enforced. See README. */
    @Column(name = "linked_item_id")
    private Long linkedItemId;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
