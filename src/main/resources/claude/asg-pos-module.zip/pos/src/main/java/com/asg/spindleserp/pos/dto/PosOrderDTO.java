package com.asg.spindleserp.pos.dto;

import lombok.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosOrderDTO {
    private Long id;
    private Long organizationId;
    private String orderNo;
    private String orderType;       // DINE_IN | TAKEAWAY | DELIVERY
    private Long tableId;
    private String tableNo;
    private String customerName;
    private String customerPhone;
    private String status;          // OPEN | SENT_TO_KITCHEN | READY | SERVED | PAID | CANCELLED
    private BigDecimal subtotal;
    private BigDecimal discount;
    private BigDecimal tax;
    private BigDecimal total;
    private String paymentMethod;
    private String remarks;
    private String openedBy;
    private String openedAt;
    private String paidAt;
    private String createdAt;

    @Builder.Default
    private List<PosOrderItemDTO> items = new ArrayList<>();
}
