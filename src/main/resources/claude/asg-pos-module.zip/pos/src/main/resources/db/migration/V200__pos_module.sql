-- ══════════════════════════════════════════════════════════════════════
-- V200__pos_module.sql
-- POS module — categories, menu items, tables, orders, order lines,
-- table bookings.
--
-- ★ Renumber this migration to match your actual next Flyway version
--   (V104 was the most recent one referenced in the Travel module notes —
--   this file assumes nothing after that has been applied yet).
--
-- Multi-tenancy: organization_id is a plain BIGINT set server-side from
-- SecurityHelper.requireOrgId() / ContextProvider, same convention as
-- Warehouse / Item / Department — no FK to org table enforced here,
-- matching the rest of the schema.
-- ══════════════════════════════════════════════════════════════════════

CREATE TABLE pos_categories (
    id              BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    name            VARCHAR(100) NOT NULL,
    sort_order      INT NOT NULL DEFAULT 0,
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP,
    updated_at      TIMESTAMP,
    CONSTRAINT uq_pos_cat_org_name UNIQUE (organization_id, name)
);
CREATE INDEX idx_pos_cat_org ON pos_categories(organization_id);

CREATE TABLE pos_menu_items (
    id              BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    category_id     BIGINT REFERENCES pos_categories(id),
    item_code       VARCHAR(30),
    item_name       VARCHAR(150) NOT NULL,
    description     TEXT,
    unit_price      NUMERIC(14,2) NOT NULL DEFAULT 0,
    stock_qty       NUMERIC(12,2) NOT NULL DEFAULT 0,
    track_stock     BOOLEAN NOT NULL DEFAULT TRUE,
    available       BOOLEAN NOT NULL DEFAULT TRUE,
    image_url       VARCHAR(500),
    linked_item_id  BIGINT,  -- ★ optional bridge to inv_items, not enforced as FK
    created_at      TIMESTAMP,
    updated_at      TIMESTAMP,
    CONSTRAINT uq_pos_item_org_code UNIQUE (organization_id, item_code)
);
CREATE INDEX idx_pos_item_org   ON pos_menu_items(organization_id);
CREATE INDEX idx_pos_item_cat   ON pos_menu_items(category_id);
CREATE INDEX idx_pos_item_avail ON pos_menu_items(available);

CREATE TABLE pos_tables (
    id              BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    table_no        VARCHAR(20) NOT NULL,
    section         VARCHAR(50),
    capacity        INT NOT NULL DEFAULT 2,
    status          VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
    created_at      TIMESTAMP,
    updated_at      TIMESTAMP,
    CONSTRAINT uq_pos_table_org_no UNIQUE (organization_id, table_no),
    CONSTRAINT ck_pos_table_status CHECK (status IN ('AVAILABLE','OCCUPIED','RESERVED','CLEANING'))
);
CREATE INDEX idx_pos_table_org ON pos_tables(organization_id);

CREATE TABLE pos_orders (
    id              BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    order_no        VARCHAR(30),
    order_type      VARCHAR(20) NOT NULL,
    pos_table_id    BIGINT REFERENCES pos_tables(id),
    customer_name   VARCHAR(150),
    customer_phone  VARCHAR(30),
    status          VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    subtotal        NUMERIC(14,2) NOT NULL DEFAULT 0,
    discount        NUMERIC(14,2) NOT NULL DEFAULT 0,
    tax             NUMERIC(14,2) NOT NULL DEFAULT 0,
    total           NUMERIC(14,2) NOT NULL DEFAULT 0,
    payment_method  VARCHAR(20),
    remarks         TEXT,
    opened_by       VARCHAR(100),
    opened_at       TIMESTAMP,
    paid_at         TIMESTAMP,
    created_at      TIMESTAMP,
    updated_at      TIMESTAMP,
    CONSTRAINT uq_pos_order_org_no UNIQUE (organization_id, order_no),
    CONSTRAINT ck_pos_order_type   CHECK (order_type IN ('DINE_IN','TAKEAWAY','DELIVERY')),
    CONSTRAINT ck_pos_order_status CHECK (status IN ('OPEN','SENT_TO_KITCHEN','READY','SERVED','PAID','CANCELLED'))
);
CREATE INDEX idx_pos_order_org    ON pos_orders(organization_id);
CREATE INDEX idx_pos_order_status ON pos_orders(status);
CREATE INDEX idx_pos_order_table  ON pos_orders(pos_table_id);

CREATE TABLE pos_order_items (
    id                  BIGSERIAL PRIMARY KEY,
    pos_order_id        BIGINT NOT NULL REFERENCES pos_orders(id) ON DELETE CASCADE,
    menu_item_id         BIGINT REFERENCES pos_menu_items(id),
    item_name_snapshot   VARCHAR(150),
    qty                  NUMERIC(10,2) NOT NULL DEFAULT 1,
    unit_price           NUMERIC(14,2) NOT NULL,
    line_total           NUMERIC(14,2) NOT NULL,
    kitchen_status       VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    notes                VARCHAR(300),
    created_at           TIMESTAMP,
    updated_at           TIMESTAMP,
    CONSTRAINT ck_pos_oi_kstatus CHECK (kitchen_status IN ('PENDING','PREPARING','READY','SERVED'))
);
CREATE INDEX idx_pos_oi_order   ON pos_order_items(pos_order_id);
CREATE INDEX idx_pos_oi_kstatus ON pos_order_items(kitchen_status);

CREATE TABLE pos_table_bookings (
    id              BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    pos_table_id    BIGINT REFERENCES pos_tables(id),
    guest_name      VARCHAR(150) NOT NULL,
    guest_phone     VARCHAR(30) NOT NULL,
    party_size      INT NOT NULL DEFAULT 2,
    booking_time    TIMESTAMP NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'BOOKED',
    remarks         TEXT,
    created_at      TIMESTAMP,
    updated_at      TIMESTAMP,
    CONSTRAINT ck_pos_tb_status CHECK (status IN ('BOOKED','SEATED','CANCELLED','NO_SHOW'))
);
CREATE INDEX idx_pos_tb_org   ON pos_table_bookings(organization_id);
CREATE INDEX idx_pos_tb_table ON pos_table_bookings(pos_table_id);
CREATE INDEX idx_pos_tb_time  ON pos_table_bookings(booking_time);
