package com.asg.spindleserp.pos.service;

import com.asg.spindleserp.pos.dto.PosCategoryDTO;
import com.asg.spindleserp.pos.dto.PosMenuItemDTO;
import com.asg.spindleserp.pos.entity.PosCategory;
import com.asg.spindleserp.pos.entity.PosMenuItem;
import com.asg.spindleserp.pos.repository.PosCategoryRepository;
import com.asg.spindleserp.pos.repository.PosMenuItemRepository;
import com.asg.spindleserp.security.auth.SecurityHelper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * PosMenuServiceImpl
 *
 * ★ organizationId is read via SecurityHelper.requireOrgId() on every write
 *   and used to scope every read — never trusted from the client payload,
 *   same convention as the rest of the app (see Spindle memory notes on
 *   multi-tenancy).
 */
@Service
@RequiredArgsConstructor
public class PosMenuServiceImpl implements PosMenuService {

    private final PosCategoryRepository categoryRepository;
    private final PosMenuItemRepository menuItemRepository;

    // ── Categories ───────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public List<PosCategoryDTO> listCategories() {
        Long orgId = SecurityHelper.requireOrgId();
        return categoryRepository.findByOrganizationIdAndActiveTrueOrderBySortOrderAscNameAsc(orgId)
                .stream().map(this::toDTO).toList();
    }

    @Override
    @Transactional
    public PosCategoryDTO saveCategory(PosCategoryDTO dto) {
        Long orgId = SecurityHelper.requireOrgId();
        PosCategory entity;
        if (dto.getId() != null) {
            entity = categoryRepository.findById(dto.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Category #" + dto.getId() + " not found."));
        } else {
            if (categoryRepository.existsByOrganizationIdAndNameIgnoreCase(orgId, dto.getName())) {
                throw new IllegalArgumentException("A category named \"" + dto.getName() + "\" already exists.");
            }
            entity = PosCategory.builder().organizationId(orgId).createdAt(LocalDateTime.now()).build();
        }
        entity.setName(dto.getName());
        entity.setSortOrder(dto.getSortOrder() != null ? dto.getSortOrder() : 0);
        entity.setActive(true);
        entity.setUpdatedAt(LocalDateTime.now());
        return toDTO(categoryRepository.save(entity));
    }

    // ── Menu items ───────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public List<PosMenuItemDTO> listMenuItems(Long categoryId, String search, boolean onlyAvailable) {
        Long orgId = SecurityHelper.requireOrgId();
        List<PosMenuItem> items = (categoryId != null)
                ? menuItemRepository.findByOrganizationIdAndCategoryIdOrderByItemNameAsc(orgId, categoryId)
                : menuItemRepository.findByOrganizationIdOrderByItemNameAsc(orgId);

        String needle = (search == null) ? "" : search.trim().toLowerCase();

        return items.stream()
                .filter(i -> !onlyAvailable || i.isAvailable())
                .filter(i -> needle.isEmpty()
                        || i.getItemName().toLowerCase().contains(needle)
                        || (i.getItemCode() != null && i.getItemCode().toLowerCase().contains(needle)))
                .map(this::toDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public PosMenuItemDTO findById(Long id) {
        return toDTO(findEntity(id));
    }

    @Override
    @Transactional
    public PosMenuItemDTO save(PosMenuItemDTO dto) {
        Long orgId = SecurityHelper.requireOrgId();
        PosMenuItem entity;
        if (dto.getId() != null) {
            entity = findEntity(dto.getId());
        } else {
            if (dto.getItemCode() != null && !dto.getItemCode().isBlank()
                    && menuItemRepository.existsByOrganizationIdAndItemCode(orgId, dto.getItemCode())) {
                throw new IllegalArgumentException("Item code \"" + dto.getItemCode() + "\" is already in use.");
            }
            entity = PosMenuItem.builder().organizationId(orgId).createdAt(LocalDateTime.now()).build();
        }

        entity.setItemCode(dto.getItemCode());
        entity.setItemName(dto.getItemName());
        entity.setDescription(dto.getDescription());
        entity.setUnitPrice(dto.getUnitPrice() != null ? dto.getUnitPrice() : BigDecimal.ZERO);
        entity.setStockQty(dto.getStockQty() != null ? dto.getStockQty() : BigDecimal.ZERO);
        entity.setTrackStock(dto.isTrackStock());
        entity.setAvailable(dto.isAvailable());
        entity.setImageUrl(dto.getImageUrl());
        entity.setLinkedItemId(dto.getLinkedItemId());
        entity.setUpdatedAt(LocalDateTime.now());

        if (dto.getCategoryId() != null) {
            PosCategory cat = categoryRepository.findById(dto.getCategoryId())
                    .orElseThrow(() -> new IllegalArgumentException("Category #" + dto.getCategoryId() + " not found."));
            entity.setCategory(cat);
        } else {
            entity.setCategory(null);
        }

        return toDTO(menuItemRepository.save(entity));
    }

    @Override
    @Transactional
    public PosMenuItemDTO updateStock(Long id, BigDecimal newQty) {
        PosMenuItem entity = findEntity(id);
        entity.setStockQty(newQty != null ? newQty : BigDecimal.ZERO);
        entity.setUpdatedAt(LocalDateTime.now());
        return toDTO(menuItemRepository.save(entity));
    }

    @Override
    @Transactional
    public PosMenuItemDTO adjustStock(Long id, BigDecimal delta) {
        PosMenuItem entity = findEntity(id);
        BigDecimal current = entity.getStockQty() != null ? entity.getStockQty() : BigDecimal.ZERO;
        BigDecimal updated = current.add(delta);
        entity.setStockQty(updated.max(BigDecimal.ZERO));
        entity.setUpdatedAt(LocalDateTime.now());
        return toDTO(menuItemRepository.save(entity));
    }

    @Override
    @Transactional
    public PosMenuItemDTO toggleAvailability(Long id) {
        PosMenuItem entity = findEntity(id);
        entity.setAvailable(!entity.isAvailable());
        entity.setUpdatedAt(LocalDateTime.now());
        return toDTO(menuItemRepository.save(entity));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        menuItemRepository.delete(findEntity(id));
    }

    // ── Private ──────────────────────────────────────────────────────────

    private PosMenuItem findEntity(Long id) {
        return menuItemRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Menu item #" + id + " not found."));
    }

    private PosCategoryDTO toDTO(PosCategory c) {
        return PosCategoryDTO.builder()
                .id(c.getId()).organizationId(c.getOrganizationId())
                .name(c.getName()).sortOrder(c.getSortOrder()).active(c.isActive())
                .build();
    }

    private PosMenuItemDTO toDTO(PosMenuItem i) {
        return PosMenuItemDTO.builder()
                .id(i.getId())
                .organizationId(i.getOrganizationId())
                .categoryId(i.getCategory() != null ? i.getCategory().getId() : null)
                .categoryName(i.getCategory() != null ? i.getCategory().getName() : null)
                .itemCode(i.getItemCode())
                .itemName(i.getItemName())
                .description(i.getDescription())
                .unitPrice(i.getUnitPrice())
                .stockQty(i.getStockQty())
                .trackStock(i.isTrackStock())
                .available(i.isAvailable())
                .imageUrl(i.getImageUrl())
                .linkedItemId(i.getLinkedItemId())
                .createdAt(i.getCreatedAt() != null ? i.getCreatedAt().toString() : null)
                .updatedAt(i.getUpdatedAt() != null ? i.getUpdatedAt().toString() : null)
                .build();
    }
}
