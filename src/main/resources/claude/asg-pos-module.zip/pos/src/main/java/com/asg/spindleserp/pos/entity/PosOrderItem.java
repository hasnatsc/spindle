package com.asg.spindleserp.pos.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "pos_order_items",
        indexes = {
                @Index(name = "idx_pos_oi_order", columnList = "pos_order_id"),
                @Index(name = "idx_pos_oi_kstatus", columnList = "kitchen_status")
        })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosOrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pos_order_id", nullable = false)
    private PosOrder order;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "menu_item_id")
    private PosMenuItem menuItem;

    /** Captured at add-time so historical tickets survive later menu edits. */
    @Column(name = "item_name_snapshot", length = 150)
    private String itemNameSnapshot;

    @Builder.Default
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal qty = BigDecimal.ONE;

    @Column(name = "unit_price", nullable = false, precision = 14, scale = 2)
    private BigDecimal unitPrice;

    @Column(name = "line_total", nullable = false, precision = 14, scale = 2)
    private BigDecimal lineTotal;

    /** PENDING | PREPARING | READY | SERVED — driven by the Kitchen screen */
    @Builder.Default
    @Column(name = "kitchen_status", nullable = false, length = 20)
    private String kitchenStatus = "PENDING";

    @Column(length = 300)
    private String notes;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
