package com.asg.spindleserp.pos.repository;

import com.asg.spindleserp.pos.entity.PosMenuItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PosMenuItemRepository extends JpaRepository<PosMenuItem, Long> {

    List<PosMenuItem> findByOrganizationIdOrderByItemNameAsc(Long organizationId);

    List<PosMenuItem> findByOrganizationIdAndCategoryIdOrderByItemNameAsc(Long organizationId, Long categoryId);

    List<PosMenuItem> findByOrganizationIdAndAvailableTrueOrderByItemNameAsc(Long organizationId);

    Optional<PosMenuItem> findByOrganizationIdAndItemCode(Long organizationId, String itemCode);

    boolean existsByOrganizationIdAndItemCode(Long organizationId, String itemCode);
}
