package com.asg.spindleserp.pos.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pos_orders",
        uniqueConstraints = @UniqueConstraint(name = "uq_pos_order_org_no", columnNames = {"organization_id", "order_no"}),
        indexes = {
                @Index(name = "idx_pos_order_org", columnList = "organization_id"),
                @Index(name = "idx_pos_order_status", columnList = "status"),
                @Index(name = "idx_pos_order_table", columnList = "pos_table_id")
        })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "organization_id", nullable = false)
    private Long organizationId;

    @Column(name = "order_no", length = 30)
    private String orderNo;

    /** DINE_IN | TAKEAWAY | DELIVERY */
    @Column(name = "order_type", nullable = false, length = 20)
    private String orderType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pos_table_id")
    private PosTable table;

    @Column(name = "customer_name", length = 150)
    private String customerName;

    @Column(name = "customer_phone", length = 30)
    private String customerPhone;

    /** OPEN | SENT_TO_KITCHEN | READY | SERVED | PAID | CANCELLED */
    @Builder.Default
    @Column(nullable = false, length = 20)
    private String status = "OPEN";

    @Builder.Default
    @Column(precision = 14, scale = 2)
    private BigDecimal subtotal = BigDecimal.ZERO;

    @Builder.Default
    @Column(precision = 14, scale = 2)
    private BigDecimal discount = BigDecimal.ZERO;

    @Builder.Default
    @Column(precision = 14, scale = 2)
    private BigDecimal tax = BigDecimal.ZERO;

    @Builder.Default
    @Column(precision = 14, scale = 2)
    private BigDecimal total = BigDecimal.ZERO;

    /** CASH | CARD | MOBILE — set at checkout */
    @Column(name = "payment_method", length = 20)
    private String paymentMethod;

    @Column(columnDefinition = "text")
    private String remarks;

    @Column(name = "opened_by", length = 100)
    private String openedBy;

    @Column(name = "opened_at")
    private LocalDateTime openedAt;

    @Column(name = "paid_at")
    private LocalDateTime paidAt;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Builder.Default
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PosOrderItem> items = new ArrayList<>();
}
