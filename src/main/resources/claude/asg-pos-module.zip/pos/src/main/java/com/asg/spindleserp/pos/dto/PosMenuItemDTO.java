package com.asg.spindleserp.pos.dto;

import lombok.*;

import java.math.BigDecimal;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosMenuItemDTO {
    private Long id;
    private Long organizationId;
    private Long categoryId;
    private String categoryName;
    private String itemCode;
    private String itemName;
    private String description;
    private BigDecimal unitPrice;
    private BigDecimal stockQty;
    private boolean trackStock;
    private boolean available;
    private String imageUrl;
    private Long linkedItemId;
    private String createdAt;
    private String updatedAt;
}
