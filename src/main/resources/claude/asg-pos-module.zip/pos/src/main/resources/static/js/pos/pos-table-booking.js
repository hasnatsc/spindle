/* pos/pos-table-booking.js — /js/pos/pos-table-booking.js   JS prefix: tb* */

(function () {
  'use strict';
  var Shell = window.PosShell;
  var dt = null; // DataTables instance

  document.addEventListener('DOMContentLoaded', function () {
    tbLoadFloor();
    tbLoadTableOptions();
    tbInitTable();
  });

  // ── FLOOR PLAN ───────────────────────────────────────────────────────
  function tbLoadFloor() {
    var floor = document.getElementById('tbFloor');
    Shell.fetchJson('/pos/tables/list', { method: 'GET' })
      .then(function (tables) {
        if (!tables || !tables.length) {
          floor.innerHTML = '<div class="pos-empty">No tables yet — add one to get started.</div>';
          return;
        }
        floor.innerHTML = tables.map(function (t) {
          return '' +
            '<div class="tb-tile tb-tile-' + t.status + '" onclick="tbCycleStatus(' + t.id + ', \'' + t.status + '\')">' +
              '<div class="no">' + Shell.esc(t.tableNo) + '</div>' +
              '<div class="meta">' + (t.section ? Shell.esc(t.section) + ' · ' : '') + t.capacity + ' seats</div>' +
              (t.currentOrderNo ? '<div class="order-ref">' + Shell.esc(t.currentOrderNo) + '</div>' : '') +
            '</div>';
        }).join('');
      })
      .catch(function () { floor.innerHTML = '<div class="pos-empty">Couldn\u2019t load the floor plan.</div>'; });
  }

  function tbLoadTableOptions() {
    Shell.fetchJson('/pos/tables/list', { method: 'GET' })
      .then(function (tables) {
        var sel = document.getElementById('tbBookingTable');
        sel.innerHTML = '<option value="">Unassigned</option>' + (tables || []).map(function (t) {
          return '<option value="' + t.id + '">' + Shell.esc(t.tableNo) + '</option>';
        }).join('');
      })
      .catch(function () {});
  }

  window.tbCycleStatus = function (id, currentStatus) {
    if (typeof Swal === 'undefined') {
      var next = { AVAILABLE: 'OCCUPIED', OCCUPIED: 'CLEANING', CLEANING: 'AVAILABLE', RESERVED: 'AVAILABLE' }[currentStatus] || 'AVAILABLE';
      tbSetTableStatus(id, next);
      return;
    }
    Swal.fire({
      title: 'Set table status',
      input: 'select',
      inputOptions: { AVAILABLE: 'Available', OCCUPIED: 'Occupied', RESERVED: 'Reserved', CLEANING: 'Cleaning' },
      inputValue: currentStatus,
      showCancelButton: true,
      confirmButtonColor: '#E8892B',
      confirmButtonText: 'Update'
    }).then(function (r) {
      if (r.isConfirmed && r.value) tbSetTableStatus(id, r.value);
    });
  };

  function tbSetTableStatus(id, status) {
    Shell.fetchJson('/pos/tables/status/' + id, { method: 'POST', body: JSON.stringify({ status: status }) })
      .then(function () { tbLoadFloor(); })
      .catch(function () { Shell.warn('Could not update the table.'); });
  }

  window.tbOpenTableModal = function () {
    document.getElementById('tbNewTableNo').value = '';
    document.getElementById('tbNewTableSection').value = '';
    document.getElementById('tbNewTableCapacity').value = '2';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('tbTableModal')).show();
  };

  window.tbSaveTable = function () {
    var tableNo = document.getElementById('tbNewTableNo').value.trim();
    if (!tableNo) { Shell.warn('Enter a table number.'); return; }
    var dto = {
      tableNo: tableNo,
      section: document.getElementById('tbNewTableSection').value.trim() || null,
      capacity: parseInt(document.getElementById('tbNewTableCapacity').value, 10) || 2
    };
    Shell.fetchJson('/pos/tables/save', { method: 'POST', body: JSON.stringify(dto) })
      .then(function (res) {
        if (!res.success) throw new Error(res.message || 'Could not add the table.');
        bootstrap.Modal.getOrCreateInstance(document.getElementById('tbTableModal')).hide();
        tbLoadFloor();
        tbLoadTableOptions();
      })
      .catch(function (err) { Shell.warn(err.message); });
  };

  // ── BOOKINGS TABLE ───────────────────────────────────────────────────
  function tbInitTable() {
    if (!window.jQuery || !jQuery.fn.DataTable) {
      document.querySelector('#tbBookingsTable tbody').innerHTML =
        '<tr><td colspan="9" class="pos-empty">DataTables isn\u2019t loaded on this page.</td></tr>';
      return;
    }
    dt = jQuery('#tbBookingsTable').DataTable({
      serverSide: true,
      processing: true,
      order: [],
      ajax: {
        url: '/pos/table-bookings/list',
        data: function (d) { d.date = document.getElementById('tbDateFilter').value || ''; }
      },
      columns: [
        { data: 'sl', orderable: false, width: '30px' },
        { data: 'guest_name' },
        { data: 'guest_phone' },
        { data: 'party_size', className: 'text-center' },
        { data: 'booking_time' },
        { data: 'table_no' },
        { data: 'status', render: function (s) { return '<span class="pos-badge ' + tbStatusClass(s) + '">' + Shell.esc(s) + '</span>'; } },
        { data: 'remarks' },
        {
          data: null, orderable: false, className: 'text-end',
          render: function (row) {
            var buttons = '';
            if (row.status === 'BOOKED') {
              buttons += '<button type="button" class="pos-btn pos-btn-success pos-btn-sm" onclick="tbSeat(' + row.id + ')">Seat</button> ';
              buttons += '<button type="button" class="pos-btn pos-btn-outline pos-btn-sm" onclick="tbCancel(' + row.id + ')">Cancel</button>';
            }
            return buttons;
          }
        }
      ]
    });
  }

  function tbStatusClass(status) {
    if (status === 'BOOKED') return 'pos-badge-amber';
    if (status === 'SEATED') return 'pos-badge-green';
    if (status === 'CANCELLED' || status === 'NO_SHOW') return 'pos-badge-red';
    return 'pos-badge-grey';
  }

  window.tbReloadTable = function () { if (dt) dt.ajax.reload(); };

  window.tbSeat = function (id) {
    Shell.fetchJson('/pos/table-bookings/seat/' + id, { method: 'POST' })
      .then(function (res) {
        if (!res.success) throw new Error(res.message || 'Could not seat this booking.');
        Shell.showMessage('tbMessages', 'Guest seated.', true);
        tbReloadTable();
        tbLoadFloor();
      })
      .catch(function (err) { Shell.showMessage('tbMessages', err.message, false); });
  };

  window.tbCancel = function (id) {
    Shell.confirmAction({ title: 'Cancel this booking?', icon: 'warning', confirmText: 'Cancel booking', confirmColor: '#D64545' })
      .then(function (confirmed) {
        if (!confirmed) return;
        Shell.fetchJson('/pos/table-bookings/cancel/' + id, { method: 'POST', body: JSON.stringify({ reason: 'Cancelled at front desk' }) })
          .then(function (res) {
            if (!res.success) throw new Error(res.message || 'Could not cancel this booking.');
            Shell.showMessage('tbMessages', 'Booking cancelled.', true);
            tbReloadTable();
          })
          .catch(function (err) { Shell.showMessage('tbMessages', err.message, false); });
      });
  };

  // ── BOOKING MODAL ────────────────────────────────────────────────────
  window.tbOpenBookingModal = function () {
    document.getElementById('tbBookingId').value = '';
    document.getElementById('tbGuestName').value = '';
    document.getElementById('tbGuestPhone').value = '';
    document.getElementById('tbPartySize').value = '2';
    document.getElementById('tbBookingTable').value = '';
    document.getElementById('tbBookingTime').value = '';
    document.getElementById('tbBookingRemarks').value = '';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('tbBookingModal')).show();
  };

  window.tbSaveBooking = function () {
    var guestName = document.getElementById('tbGuestName').value.trim();
    var guestPhone = document.getElementById('tbGuestPhone').value.trim();
    var bookingTime = document.getElementById('tbBookingTime').value;

    if (!guestName || !guestPhone) { Shell.warn('Enter the guest\u2019s name and phone number.'); return; }
    if (!bookingTime) { Shell.warn('Choose a date and time for the booking.'); return; }

    var dto = {
      id: document.getElementById('tbBookingId').value || null,
      guestName: guestName,
      guestPhone: guestPhone,
      partySize: parseInt(document.getElementById('tbPartySize').value, 10) || 2,
      tableId: document.getElementById('tbBookingTable').value || null,
      bookingTime: bookingTime,
      remarks: document.getElementById('tbBookingRemarks').value.trim()
    };

    Shell.fetchJson('/pos/table-bookings/save', { method: 'POST', body: JSON.stringify(dto) })
      .then(function (res) {
        if (!res.success) throw new Error(res.message || 'Could not save the booking.');
        bootstrap.Modal.getOrCreateInstance(document.getElementById('tbBookingModal')).hide();
        Shell.showMessage('tbMessages', 'Booking saved.', true);
        tbReloadTable();
      })
      .catch(function (err) { Shell.warn(err.message); });
  };
})();
