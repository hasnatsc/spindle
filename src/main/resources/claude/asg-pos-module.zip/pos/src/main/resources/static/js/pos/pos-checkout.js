/* pos/pos-checkout.js — /js/pos/pos-checkout.js   JS prefix: co* */

(function () {
  'use strict';
  var Shell = window.PosShell;

  var state = {
    orderId: null,
    orderNo: null,
    orderType: 'DINE_IN',
    tableId: null,
    categoryId: '',
    search: '',
    paymentMethod: null,
    lines: [],       // { menuItemId, itemName, unitPrice, qty, stockQty, trackStock }
    menuById: {}
  };
  var searchTimer = null;
  var saveTimer = null;

  document.addEventListener('DOMContentLoaded', function () {
    coLoadCategories();
    coLoadTables();
    coLoadItems();
    coLoadRecent();
    renderCart();
  });

  // ── ORDER TYPE / TABLE ───────────────────────────────────────────────
  window.coSetOrderType = function (el) {
    document.querySelectorAll('.co-type-btn').forEach(function (b) { b.classList.remove('active'); });
    el.classList.add('active');
    state.orderType = el.dataset.type;
    document.getElementById('coTableSelect').style.display = (state.orderType === 'DINE_IN') ? '' : 'none';
    if (state.orderType !== 'DINE_IN') state.tableId = null;
    scheduleSave();
  };

  function coLoadTables() {
    Shell.fetchJson('/pos/tables/for-checkout', { method: 'GET' })
      .then(function (res) {
        var sel = document.getElementById('coTableSelect');
        var tables = (res && res.items) || [];
        sel.innerHTML = '<option value="">Select a table…</option>' + tables.map(function (t) {
          var busy = t.currentOrderNo ? ' (order ' + Shell.esc(t.currentOrderNo) + ')' : '';
          return '<option value="' + t.id + '">' + Shell.esc(t.tableNo) + ' — ' + Shell.esc(t.status) + busy + '</option>';
        }).join('');
      })
      .catch(function () { /* table picker just stays empty */ });
  }

  window.coTableChanged = function () {
    var tableId = document.getElementById('coTableSelect').value;
    state.tableId = tableId || null;
    if (!tableId) return;

    Shell.fetchJson('/pos/orders/open?tableId=' + tableId, { method: 'GET' })
      .then(function (res) {
        var order = res && res.obj && res.obj.defaultData;
        if (order) {
          loadOrderIntoState(order);
        } else {
          scheduleSave();
        }
      });
  };

  function loadOrderIntoState(order) {
    state.orderId = order.id;
    state.orderNo = order.orderNo;
    state.orderType = order.orderType;
    state.tableId = order.tableId;
    state.lines = (order.items || []).map(function (li) {
      return { menuItemId: li.menuItemId, itemName: li.itemName, unitPrice: Number(li.unitPrice), qty: Number(li.qty) };
    });
    document.getElementById('coDiscount').value = order.discount || 0;
    document.getElementById('coTaxRate').value = 0;
    document.getElementById('coOrderNo').textContent = order.orderNo ? ('#' + order.orderNo) : '';
    renderCart();
  }

  // ── CATEGORY / SEARCH ────────────────────────────────────────────────
  function coLoadCategories() {
    Shell.fetchJson('/pos/categories/list', { method: 'GET' })
      .then(function (cats) {
        var wrap = document.getElementById('coCategoryTabs');
        var allTab = wrap.querySelector('[data-id=""]');
        wrap.innerHTML = '';
        wrap.appendChild(allTab);
        (cats || []).forEach(function (c) {
          var btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'pos-tab';
          btn.dataset.id = c.id;
          btn.textContent = c.name;
          btn.onclick = function () { window.coSelectCategory(btn); };
          wrap.appendChild(btn);
        });
      })
      .catch(function () {});
  }

  window.coSelectCategory = function (el) {
    document.querySelectorAll('#coCategoryTabs .pos-tab').forEach(function (b) { b.classList.remove('active'); });
    el.classList.add('active');
    state.categoryId = el.dataset.id || '';
    coLoadItems();
  };

  window.coDebouncedSearch = function () {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () {
      state.search = document.getElementById('coSearch').value;
      coLoadItems();
    }, 300);
  };

  function coLoadItems() {
    var params = new URLSearchParams({ onlyAvailable: 'true' });
    if (state.categoryId) params.set('categoryId', state.categoryId);
    if (state.search) params.set('search', state.search);

    var grid = document.getElementById('coItemGrid');
    grid.innerHTML = '<div class="pos-empty">Loading menu…</div>';

    Shell.fetchJson('/pos/menu-items/list?' + params.toString(), { method: 'GET' })
      .then(function (res) {
        var items = (res && res.items) || [];
        items.forEach(function (i) { state.menuById[i.id] = i; });
        if (!items.length) {
          grid.innerHTML = '<div class="pos-empty">No items in this category.</div>';
          return;
        }
        grid.innerHTML = items.map(renderTile).join('');
      })
      .catch(function () { grid.innerHTML = '<div class="pos-empty">Couldn\u2019t load the menu.</div>'; });
  }

  function renderTile(item) {
    var outOfStock = item.trackStock && Number(item.stockQty) <= 0;
    var stockNote = item.trackStock ? (outOfStock ? 'Out of stock' : Number(item.stockQty) + ' in stock') : 'Made to order';
    return '' +
      '<button type="button" class="co-item-tile' + (outOfStock ? ' unavailable' : '') + '" ' +
        (outOfStock ? 'disabled' : 'onclick="coAddLine(' + item.id + ')"') + '>' +
        '<div class="name">' + Shell.esc(item.itemName) + '</div>' +
        '<div class="price">' + Shell.money(item.unitPrice) + '</div>' +
        '<div class="stock-note">' + stockNote + '</div>' +
      '</button>';
  }

  // ── CART ─────────────────────────────────────────────────────────────
  window.coAddLine = function (menuItemId) {
    var item = state.menuById[menuItemId];
    if (!item) return;
    var existing = state.lines.find(function (l) { return l.menuItemId === menuItemId; });
    if (existing) {
      existing.qty += 1;
    } else {
      state.lines.push({ menuItemId: menuItemId, itemName: item.itemName, unitPrice: Number(item.unitPrice), qty: 1 });
    }
    renderCart();
    scheduleSave();
  };

  window.coChangeQty = function (menuItemId, delta) {
    var line = state.lines.find(function (l) { return l.menuItemId === menuItemId; });
    if (!line) return;
    line.qty += delta;
    if (line.qty <= 0) {
      state.lines = state.lines.filter(function (l) { return l.menuItemId !== menuItemId; });
    }
    renderCart();
    scheduleSave();
  };

  window.coRemoveLine = function (menuItemId) {
    state.lines = state.lines.filter(function (l) { return l.menuItemId !== menuItemId; });
    renderCart();
    scheduleSave();
  };

  function renderCart() {
    var box = document.getElementById('coCartLines');
    if (!state.lines.length) {
      box.innerHTML = '<div class="pos-empty">Cart is empty — tap a menu item to add it.</div>';
    } else {
      box.innerHTML = state.lines.map(function (l) {
        var lineTotal = l.unitPrice * l.qty;
        return '' +
          '<div class="co-line">' +
            '<div><div class="co-line-name">' + Shell.esc(l.itemName) + '</div><div class="co-line-price">' + Shell.money(l.unitPrice) + ' each</div></div>' +
            '<div class="co-line-qty">' +
              '<button type="button" onclick="coChangeQty(' + l.menuItemId + ', -1)">−</button>' +
              '<span>' + l.qty + '</span>' +
              '<button type="button" onclick="coChangeQty(' + l.menuItemId + ', 1)">+</button>' +
            '</div>' +
            '<div class="co-line-total">' + Shell.money(lineTotal) + '</div>' +
            '<button type="button" class="co-line-remove" onclick="coRemoveLine(' + l.menuItemId + ')"><i class="fa fa-xmark"></i></button>' +
          '</div>';
      }).join('');
    }
    coRecalc();
  }

  window.coRecalc = function () {
    var subtotal = state.lines.reduce(function (s, l) { return s + (l.unitPrice * l.qty); }, 0);
    var discount = parseFloat(document.getElementById('coDiscount').value) || 0;
    var taxRate = parseFloat(document.getElementById('coTaxRate').value) || 0;
    var taxable = Math.max(subtotal - discount, 0);
    var tax = taxable * (taxRate / 100);
    var total = Math.max(taxable + tax, 0);

    document.getElementById('coSubtotal').textContent = Shell.money(subtotal);
    document.getElementById('coTotal').textContent = Shell.money(total);
  };

  window.coSelectPayment = function (el) {
    document.querySelectorAll('.co-pay-btn').forEach(function (b) { b.classList.remove('active'); });
    el.classList.add('active');
    state.paymentMethod = el.dataset.method;
  };

  // ── SAVE (debounced, keeps an order row in sync as the cart changes) ─
  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(coSaveCart, 400);
  }

  function coSaveCart() {
    if (!state.lines.length && !state.orderId) return; // nothing to persist yet

    var dto = {
      id: state.orderId,
      orderType: state.orderType,
      tableId: state.orderType === 'DINE_IN' ? state.tableId : null,
      remarks: null,
      items: state.lines.map(function (l) {
        return { menuItemId: l.menuItemId, itemName: l.itemName, unitPrice: l.unitPrice, qty: l.qty };
      })
    };

    Shell.fetchJson('/pos/orders/save', { method: 'POST', body: JSON.stringify(dto) })
      .then(function (res) {
        if (!res.success) throw new Error(res.message || 'Could not save the order.');
        var order = res.obj.defaultData;
        state.orderId = order.id;
        state.orderNo = order.orderNo;
        document.getElementById('coOrderNo').textContent = '#' + order.orderNo;
      })
      .catch(function (err) { Shell.warn(err.message); });
  }

  // ── SEND TO KITCHEN / CHECKOUT / NEW ORDER ──────────────────────────
  window.coSendToKitchen = function () {
    if (!state.lines.length) { Shell.warn('Add at least one item first.'); return; }
    coSaveCart();
    setTimeout(function () {
      if (!state.orderId) { Shell.warn('Still saving the order — try again in a moment.'); return; }
      Shell.fetchJson('/pos/orders/send-to-kitchen/' + state.orderId, { method: 'POST' })
        .then(function (res) {
          if (!res.success) throw new Error(res.message || 'Could not send this order to the kitchen.');
          Shell.showMessage('coMessages', 'Sent to the kitchen.', true);
          coLoadRecent();
        })
        .catch(function (err) { Shell.showMessage('coMessages', err.message, false); });
    }, 500);
  };

  window.coCheckout = function () {
    if (!state.lines.length) { Shell.warn('Add at least one item first.'); return; }
    if (!state.paymentMethod) { Shell.warn('Choose a payment method.'); return; }

    coSaveCart();
    setTimeout(function () {
      if (!state.orderId) { Shell.warn('Still saving the order — try again in a moment.'); return; }
      var body = {
        paymentMethod: state.paymentMethod,
        discount: parseFloat(document.getElementById('coDiscount').value) || 0,
        taxRate: parseFloat(document.getElementById('coTaxRate').value) || 0
      };
      Shell.fetchJson('/pos/orders/checkout/' + state.orderId, { method: 'POST', body: JSON.stringify(body) })
        .then(function (res) {
          if (!res.success) throw new Error(res.message || 'Checkout failed.');
          var order = res.obj.defaultData;
          Shell.showMessage('coMessages', 'Order ' + order.orderNo + ' paid — ' + Shell.money(order.total) + '.', true);
          coNewOrder();
          coLoadRecent();
          coLoadTables();
        })
        .catch(function (err) { Shell.showMessage('coMessages', err.message, false); });
    }, 500);
  };

  window.coNewOrder = function () {
    state.orderId = null;
    state.orderNo = null;
    state.tableId = null;
    state.paymentMethod = null;
    state.lines = [];
    document.getElementById('coTableSelect').value = '';
    document.getElementById('coDiscount').value = '0';
    document.getElementById('coTaxRate').value = '0';
    document.getElementById('coOrderNo').textContent = '';
    document.querySelectorAll('.co-pay-btn').forEach(function (b) { b.classList.remove('active'); });
    document.getElementById('coMessages').innerHTML = '';
    renderCart();
  };

  // ── RECENT ORDERS ────────────────────────────────────────────────────
  function coLoadRecent() {
    var box = document.getElementById('coRecentList');
    Shell.fetchJson('/pos/orders/recent?length=8', { method: 'GET' })
      .then(function (orders) {
        if (!orders || !orders.length) {
          box.innerHTML = '<p class="pos-empty">No orders yet today.</p>';
          return;
        }
        box.innerHTML = orders.map(function (o) {
          return '' +
            '<div class="co-recent-item">' +
              '<span class="co-recent-ref">' + Shell.esc(o.orderNo) + '</span>' +
              '<span class="pos-badge ' + statusBadgeClass(o.status) + '">' + Shell.esc(o.status) + '</span>' +
              '<span>' + Shell.money(o.total) + '</span>' +
            '</div>';
        }).join('');
      })
      .catch(function () { box.innerHTML = '<p class="pos-empty">Couldn\u2019t load recent orders.</p>'; });
  }

  function statusBadgeClass(status) {
    if (status === 'PAID') return 'pos-badge-green';
    if (status === 'CANCELLED') return 'pos-badge-red';
    if (status === 'SENT_TO_KITCHEN' || status === 'READY') return 'pos-badge-amber';
    return 'pos-badge-grey';
  }
})();
