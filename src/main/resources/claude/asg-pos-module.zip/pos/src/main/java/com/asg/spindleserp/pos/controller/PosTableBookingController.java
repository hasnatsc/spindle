package com.asg.spindleserp.pos.controller;

import com.asg.spindleserp.pos.dto.PosTableBookingDTO;
import com.asg.spindleserp.pos.dto.PosTableDTO;
import com.asg.spindleserp.pos.service.PosTableService;
import com.asg.spindleserp.security.dto.DataTableResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PosTableBookingController — the Table Booking screen (/pos/table-booking).
 *
 * REST:
 *   GET    /pos/tables/list
 *   POST   /pos/tables/save
 *   POST   /pos/tables/status/{id}         body: { status }
 *   GET    /pos/table-bookings/list?date=&search[value]=
 *   POST   /pos/table-bookings/save
 *   POST   /pos/table-bookings/seat/{id}
 *   POST   /pos/table-bookings/cancel/{id}  body: { reason }
 */
@Controller
@RequiredArgsConstructor
public class PosTableBookingController {

    private final PosTableService posTableService;

    @GetMapping("/pos/table-booking")
    public String tableBookingPage(Model model) {
        model.addAttribute("activePage", "pos-table-booking");
        model.addAttribute("pageTitle", "Table Booking");
        return "pos/pos-table-booking";
    }

    // ── Tables (floor plan) ─────────────────────────────────────────────

    @GetMapping("/pos/tables/list")
    @ResponseBody
    public List<PosTableDTO> tableList() {
        return posTableService.listTables();
    }

    @PostMapping("/pos/tables/save")
    @ResponseBody
    public Map<String, Object> tableSave(@RequestBody PosTableDTO dto) {
        return ok(() -> { posTableService.saveTable(dto); return "Table saved."; });
    }

    @PostMapping("/pos/tables/status/{id}")
    @ResponseBody
    public Map<String, Object> tableStatus(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        return ok(() -> {
            String status = String.valueOf(body.get("status"));
            return Map.of("defaultData", posTableService.updateTableStatus(id, status));
        });
    }

    // ── Bookings ─────────────────────────────────────────────────────────

    @GetMapping("/pos/table-bookings/list")
    @ResponseBody
    public DataTableResponse bookingList(
            @RequestParam(defaultValue = "1") int draw,
            @RequestParam(defaultValue = "0") int start,
            @RequestParam(defaultValue = "25") int length,
            @RequestParam(value = "search[value]", defaultValue = "") String search,
            @RequestParam(required = false) String date) {
        return posTableService.bookingsDatatable(draw, start, length, search, date);
    }

    @PostMapping("/pos/table-bookings/save")
    @ResponseBody
    public Map<String, Object> bookingSave(@RequestBody @Valid PosTableBookingDTO dto) {
        return ok(() -> { posTableService.saveBooking(dto); return "Booking saved."; });
    }

    @PostMapping("/pos/table-bookings/seat/{id}")
    @ResponseBody
    public Map<String, Object> bookingSeat(@PathVariable Long id) {
        return ok(() -> { posTableService.seatBooking(id); return "Guest seated."; });
    }

    @PostMapping("/pos/table-bookings/cancel/{id}")
    @ResponseBody
    public Map<String, Object> bookingCancel(@PathVariable Long id, @RequestBody(required = false) Map<String, Object> body) {
        return ok(() -> {
            String reason = body != null && body.get("reason") != null ? String.valueOf(body.get("reason")) : null;
            posTableService.cancelBooking(id, reason);
            return "Booking cancelled.";
        });
    }

    // ── Helper ───────────────────────────────────────────────────────────

    private Map<String, Object> ok(Checked action) {
        Map<String, Object> res = new HashMap<>();
        try {
            Object r = action.run();
            res.put("success", true);
            if (r instanceof String msg) res.put("message", msg);
            else if (r instanceof Map<?, ?> m) res.put("obj", m);
        } catch (Exception e) {
            res.put("success", false);
            res.put("message", e.getMessage());
        }
        return res;
    }

    @FunctionalInterface
    interface Checked { Object run() throws Exception; }
}
