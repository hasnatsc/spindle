package com.asg.spindleserp.pos.repository;

import com.asg.spindleserp.pos.entity.PosOrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PosOrderItemRepository extends JpaRepository<PosOrderItem, Long> {
}
