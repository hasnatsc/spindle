package com.asg.spindleserp.pos.service;

import com.asg.spindleserp.common.util.CommonUtils;
import com.asg.spindleserp.pos.dto.PosTableBookingDTO;
import com.asg.spindleserp.pos.dto.PosTableDTO;
import com.asg.spindleserp.pos.entity.PosTable;
import com.asg.spindleserp.pos.entity.PosTableBooking;
import com.asg.spindleserp.pos.repository.PosOrderRepository;
import com.asg.spindleserp.pos.repository.PosTableBookingRepository;
import com.asg.spindleserp.pos.repository.PosTableRepository;
import com.asg.spindleserp.security.auth.SecurityHelper;
import com.asg.spindleserp.security.dto.DataTableResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * PosTableServiceImpl — the floor plan (pos_tables) and the reservations
 * book (pos_table_bookings).
 *
 * ★ Table capacity conflicts (double-booking the same table/slot) are not
 *   checked — bookingsDatatable / seatBooking assume front-desk staff can
 *   see the floor plan and won't double-seat a table. Add an overlap check
 *   here if that assumption doesn't hold for your floor count.
 */
@Service
@RequiredArgsConstructor
public class PosTableServiceImpl implements PosTableService {

    private final PosTableRepository tableRepository;
    private final PosTableBookingRepository bookingRepository;
    private final PosOrderRepository orderRepository;
    private final JdbcTemplate jdbcTemplate;

    // ── TABLES ───────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public List<PosTableDTO> listTables() {
        Long orgId = SecurityHelper.requireOrgId();
        return tableRepository.findByOrganizationIdOrderByTableNoAsc(orgId).stream()
                .map(t -> {
                    PosTableDTO dto = toDTO(t);
                    orderRepository.findFirstByOrganizationIdAndTableIdAndStatusIn(
                                    orgId, t.getId(), List.of("OPEN", "SENT_TO_KITCHEN", "READY", "SERVED"))
                            .ifPresent(o -> {
                                dto.setCurrentOrderId(o.getId());
                                dto.setCurrentOrderNo(o.getOrderNo());
                            });
                    return dto;
                })
                .toList();
    }

    @Override
    @Transactional
    public PosTableDTO saveTable(PosTableDTO dto) {
        Long orgId = SecurityHelper.requireOrgId();
        PosTable entity;
        if (dto.getId() != null) {
            entity = tableRepository.findById(dto.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Table #" + dto.getId() + " not found."));
        } else {
            if (tableRepository.existsByOrganizationIdAndTableNoIgnoreCase(orgId, dto.getTableNo())) {
                throw new IllegalArgumentException("Table \"" + dto.getTableNo() + "\" already exists.");
            }
            entity = PosTable.builder().organizationId(orgId).createdAt(LocalDateTime.now()).build();
        }
        entity.setTableNo(dto.getTableNo());
        entity.setSection(dto.getSection());
        entity.setCapacity(dto.getCapacity() != null ? dto.getCapacity() : 2);
        if (dto.getStatus() != null) entity.setStatus(dto.getStatus());
        entity.setUpdatedAt(LocalDateTime.now());
        return toDTO(tableRepository.save(entity));
    }

    @Override
    @Transactional
    public PosTableDTO updateTableStatus(Long id, String status) {
        PosTable entity = tableRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Table #" + id + " not found."));
        entity.setStatus(status);
        entity.setUpdatedAt(LocalDateTime.now());
        return toDTO(tableRepository.save(entity));
    }

    // ── BOOKINGS ─────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public DataTableResponse bookingsDatatable(int draw, int start, int length, String search, String date) {
        Long orgId = SecurityHelper.requireOrgId();

        String where = "WHERE tb.organization_id = " + orgId + " ";
        if (date != null && !date.isBlank()) {
            where += " AND tb.booking_time::date = '" + date.replace("'", "''") + "'::date ";
        }
        where += CommonUtils.searchILike(search, Arrays.asList(
                "tb.guest_name", "tb.guest_phone", "t.table_no"));

        String sql = String.format("""
            SELECT
                ROW_NUMBER() OVER (ORDER BY tb.booking_time ASC) AS sl,
                COUNT(*) OVER ()                                 AS full_count,
                tb.id,
                tb.guest_name,
                tb.guest_phone,
                tb.party_size,
                TO_CHAR(tb.booking_time, 'DD-Mon-YYYY HH24:MI')  AS booking_time,
                COALESCE(t.table_no, '—')                        AS table_no,
                tb.status,
                COALESCE(tb.remarks, '—')                        AS remarks
            FROM pos_table_bookings tb
            LEFT JOIN pos_tables t ON t.id = tb.pos_table_id
            %s
            ORDER BY tb.booking_time ASC
            OFFSET %d LIMIT %d
            """, where, start, length);

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
        long total = rows.isEmpty() ? 0L : CommonUtils.toLong(rows.get(0).get("full_count"));
        return DataTableResponse.of(draw, total, total, rows);
    }

    @Override
    @Transactional
    public PosTableBookingDTO saveBooking(PosTableBookingDTO dto) {
        Long orgId = SecurityHelper.requireOrgId();
        PosTableBooking entity;
        if (dto.getId() != null) {
            entity = bookingRepository.findById(dto.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Booking #" + dto.getId() + " not found."));
        } else {
            entity = PosTableBooking.builder().organizationId(orgId).status("BOOKED")
                    .createdAt(LocalDateTime.now()).build();
        }

        entity.setGuestName(dto.getGuestName());
        entity.setGuestPhone(dto.getGuestPhone());
        entity.setPartySize(dto.getPartySize() != null ? dto.getPartySize() : 2);
        entity.setBookingTime(LocalDateTime.parse(dto.getBookingTime()));
        entity.setRemarks(dto.getRemarks());
        entity.setUpdatedAt(LocalDateTime.now());

        if (dto.getTableId() != null) {
            PosTable table = tableRepository.findById(dto.getTableId())
                    .orElseThrow(() -> new IllegalArgumentException("Table #" + dto.getTableId() + " not found."));
            entity.setTable(table);
        }

        return toDTO(bookingRepository.save(entity));
    }

    @Override
    @Transactional
    public PosTableBookingDTO seatBooking(Long id) {
        PosTableBooking entity = bookingRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Booking #" + id + " not found."));
        entity.setStatus("SEATED");
        entity.setUpdatedAt(LocalDateTime.now());

        if (entity.getTable() != null) {
            PosTable table = entity.getTable();
            table.setStatus("OCCUPIED");
            table.setUpdatedAt(LocalDateTime.now());
            tableRepository.save(table);
        }

        return toDTO(bookingRepository.save(entity));
    }

    @Override
    @Transactional
    public PosTableBookingDTO cancelBooking(Long id, String reason) {
        PosTableBooking entity = bookingRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Booking #" + id + " not found."));
        entity.setStatus("CANCELLED");
        if (reason != null && !reason.isBlank()) {
            String line = "Cancelled: " + reason;
            entity.setRemarks(entity.getRemarks() == null || entity.getRemarks().isBlank()
                    ? line : entity.getRemarks() + "\n" + line);
        }
        entity.setUpdatedAt(LocalDateTime.now());
        return toDTO(bookingRepository.save(entity));
    }

    // ── PRIVATE ──────────────────────────────────────────────────────────

    private PosTableDTO toDTO(PosTable t) {
        return PosTableDTO.builder()
                .id(t.getId())
                .organizationId(t.getOrganizationId())
                .tableNo(t.getTableNo())
                .section(t.getSection())
                .capacity(t.getCapacity())
                .status(t.getStatus())
                .build();
    }

    private PosTableBookingDTO toDTO(PosTableBooking b) {
        return PosTableBookingDTO.builder()
                .id(b.getId())
                .organizationId(b.getOrganizationId())
                .tableId(b.getTable() != null ? b.getTable().getId() : null)
                .tableNo(b.getTable() != null ? b.getTable().getTableNo() : null)
                .guestName(b.getGuestName())
                .guestPhone(b.getGuestPhone())
                .partySize(b.getPartySize())
                .bookingTime(b.getBookingTime() != null ? b.getBookingTime().toString() : null)
                .status(b.getStatus())
                .remarks(b.getRemarks())
                .build();
    }
}
