package com.asg.spindleserp.pos.dto;

import lombok.*;

import java.math.BigDecimal;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosOrderItemDTO {
    private Long id;
    private Long menuItemId;
    private String itemName;        // itemNameSnapshot, or the current menu item name if blank
    private BigDecimal qty;
    private BigDecimal unitPrice;
    private BigDecimal lineTotal;
    private String kitchenStatus;   // PENDING | PREPARING | READY | SERVED
    private String notes;
}
