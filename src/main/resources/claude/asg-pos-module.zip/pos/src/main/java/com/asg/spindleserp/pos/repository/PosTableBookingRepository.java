package com.asg.spindleserp.pos.repository;

import com.asg.spindleserp.pos.entity.PosTableBooking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PosTableBookingRepository extends JpaRepository<PosTableBooking, Long> {
}
