package com.asg.spindleserp.pos.service;

import com.asg.spindleserp.pos.dto.PosCategoryDTO;
import com.asg.spindleserp.pos.dto.PosMenuItemDTO;

import java.math.BigDecimal;
import java.util.List;

public interface PosMenuService {

    // ── Categories ───────────────────────────────────────────────────────
    List<PosCategoryDTO> listCategories();
    PosCategoryDTO saveCategory(PosCategoryDTO dto);

    // ── Menu items ───────────────────────────────────────────────────────
    /** Used by both the Menu Stock grid and the Checkout item picker. */
    List<PosMenuItemDTO> listMenuItems(Long categoryId, String search, boolean onlyAvailable);

    PosMenuItemDTO findById(Long id);

    PosMenuItemDTO save(PosMenuItemDTO dto);

    PosMenuItemDTO updateStock(Long id, BigDecimal newQty);

    PosMenuItemDTO adjustStock(Long id, BigDecimal delta);

    PosMenuItemDTO toggleAvailability(Long id);

    void delete(Long id);
}
