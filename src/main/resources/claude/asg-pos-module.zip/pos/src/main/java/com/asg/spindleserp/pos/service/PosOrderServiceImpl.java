package com.asg.spindleserp.pos.service;

import com.asg.spindleserp.pos.dto.PosOrderDTO;
import com.asg.spindleserp.pos.dto.PosOrderItemDTO;
import com.asg.spindleserp.pos.entity.*;
import com.asg.spindleserp.pos.repository.PosMenuItemRepository;
import com.asg.spindleserp.pos.repository.PosOrderRepository;
import com.asg.spindleserp.pos.repository.PosTableRepository;
import com.asg.spindleserp.security.auth.SecurityHelper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * PosOrderServiceImpl — the checkout cart lifecycle + the kitchen queue.
 *
 * ★ Order numbering: "POS-yyyyMMdd-####", sequential per organization per
 *   day via a same-day COUNT query. This is fine for a single counter but
 *   isn't safe under heavy concurrent writes — wire this to the app's
 *   existing DocumentSequenceService (see stp_document_sequences /
 *   DocumentSequenceServiceImpl) for the same guarantees the rest of the
 *   ERP's document numbers get, if POS grows beyond a light-traffic counter.
 *
 * ★ Payment / GL bridge: checkout() marks the order PAID and stamps
 *   paymentMethod/paidAt, but does NOT create a JournalEntryMaster or
 *   touch inv_items stock beyond this module's own stock_qty counter.
 *   Wiring POS payments into Accounts (cash/bank JEM) and Inventory
 *   (stock issue) is a natural next step — deliberately left out rather
 *   than guessed at, since incorrect GL postings are worse than none.
 */
@Service
@RequiredArgsConstructor
public class PosOrderServiceImpl implements PosOrderService {

    private static final List<String> OPEN_STATUSES =
            List.of("OPEN", "SENT_TO_KITCHEN", "READY", "SERVED");
    private static final List<String> KITCHEN_ACTIVE_STATUSES =
            List.of("PENDING", "PREPARING", "READY");

    private final PosOrderRepository orderRepository;
    private final PosMenuItemRepository menuItemRepository;
    private final PosTableRepository tableRepository;

    // ── LOOKUPS ──────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public PosOrderDTO findById(Long id) {
        return toDTO(findEntity(id));
    }

    @Override
    @Transactional(readOnly = true)
    public PosOrderDTO findOpenOrderForTable(Long tableId) {
        Long orgId = SecurityHelper.requireOrgId();
        return orderRepository.findFirstByOrganizationIdAndTableIdAndStatusIn(orgId, tableId, OPEN_STATUSES)
                .map(this::toDTO)
                .orElse(null);
    }

    // ── SAVE (create / update cart) ─────────────────────────────────────

    @Override
    @Transactional
    public PosOrderDTO save(PosOrderDTO dto) {
        Long orgId = SecurityHelper.requireOrgId();
        PosOrder entity;

        if (dto.getId() != null) {
            entity = findEntity(dto.getId());
        } else {
            entity = PosOrder.builder()
                    .organizationId(orgId)
                    .orderNo(nextOrderNo(orgId))
                    .status("OPEN")
                    .openedBy(SecurityHelper.currentUsername().orElse("SYSTEM"))
                    .openedAt(LocalDateTime.now())
                    .createdAt(LocalDateTime.now())
                    .build();
        }

        entity.setOrderType(dto.getOrderType());
        entity.setCustomerName(dto.getCustomerName());
        entity.setCustomerPhone(dto.getCustomerPhone());
        entity.setRemarks(dto.getRemarks());
        entity.setUpdatedAt(LocalDateTime.now());

        if ("DINE_IN".equals(dto.getOrderType()) && dto.getTableId() != null) {
            PosTable table = tableRepository.findById(dto.getTableId())
                    .orElseThrow(() -> new IllegalArgumentException("Table #" + dto.getTableId() + " not found."));
            entity.setTable(table);
            if (!"OCCUPIED".equals(table.getStatus())) {
                table.setStatus("OCCUPIED");
                table.setUpdatedAt(LocalDateTime.now());
                tableRepository.save(table);
            }
        } else {
            entity.setTable(null);
        }

        // Clear-and-reinsert line sync (CascadeType.ALL + orphanRemoval on PosOrder.items).
        entity.getItems().clear();
        BigDecimal subtotal = BigDecimal.ZERO;
        if (dto.getItems() != null) {
            for (PosOrderItemDTO lineDto : dto.getItems()) {
                PosMenuItem menuItem = (lineDto.getMenuItemId() != null)
                        ? menuItemRepository.findById(lineDto.getMenuItemId()).orElse(null)
                        : null;

                BigDecimal qty = lineDto.getQty() != null ? lineDto.getQty() : BigDecimal.ONE;
                BigDecimal unitPrice = lineDto.getUnitPrice() != null ? lineDto.getUnitPrice()
                        : (menuItem != null ? menuItem.getUnitPrice() : BigDecimal.ZERO);
                BigDecimal lineTotal = unitPrice.multiply(qty).setScale(2, RoundingMode.HALF_UP);
                subtotal = subtotal.add(lineTotal);

                PosOrderItem line = PosOrderItem.builder()
                        .order(entity)
                        .menuItem(menuItem)
                        .itemNameSnapshot(lineDto.getItemName() != null ? lineDto.getItemName()
                                : (menuItem != null ? menuItem.getItemName() : "Item"))
                        .qty(qty)
                        .unitPrice(unitPrice)
                        .lineTotal(lineTotal)
                        .kitchenStatus("PENDING")
                        .notes(lineDto.getNotes())
                        .createdAt(LocalDateTime.now())
                        .build();
                entity.getItems().add(line);
            }
        }

        entity.setSubtotal(subtotal);
        recomputeTotal(entity);

        return toDTO(orderRepository.save(entity));
    }

    // ── SEND TO KITCHEN ──────────────────────────────────────────────────

    @Override
    @Transactional
    public PosOrderDTO sendToKitchen(Long orderId) {
        PosOrder entity = findEntity(orderId);
        if (entity.getItems().isEmpty()) {
            throw new IllegalStateException("Add at least one item before sending this order to the kitchen.");
        }
        entity.setStatus("SENT_TO_KITCHEN");
        entity.setUpdatedAt(LocalDateTime.now());
        return toDTO(orderRepository.save(entity));
    }

    // ── CHECKOUT ─────────────────────────────────────────────────────────

    @Override
    @Transactional
    public PosOrderDTO checkout(Long orderId, String paymentMethod, BigDecimal discount, BigDecimal taxRate) {
        PosOrder entity = findEntity(orderId);
        if (entity.getItems().isEmpty()) {
            throw new IllegalStateException("This order has no items to charge for.");
        }
        if (paymentMethod == null || paymentMethod.isBlank()) {
            throw new IllegalArgumentException("Choose a payment method before checking out.");
        }

        entity.setDiscount(discount != null ? discount : BigDecimal.ZERO);
        BigDecimal rate = taxRate != null ? taxRate : BigDecimal.ZERO;
        BigDecimal taxable = entity.getSubtotal().subtract(entity.getDiscount()).max(BigDecimal.ZERO);
        entity.setTax(taxable.multiply(rate).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
        recomputeTotal(entity);

        entity.setPaymentMethod(paymentMethod);
        entity.setStatus("PAID");
        entity.setPaidAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());

        // Deduct stock for tracked items.
        for (PosOrderItem line : entity.getItems()) {
            if (line.getMenuItem() != null && line.getMenuItem().isTrackStock()) {
                PosMenuItem mi = line.getMenuItem();
                BigDecimal remaining = mi.getStockQty().subtract(line.getQty()).max(BigDecimal.ZERO);
                mi.setStockQty(remaining);
                mi.setUpdatedAt(LocalDateTime.now());
                menuItemRepository.save(mi);
            }
        }

        freeTableAfterOrder(entity, "CLEANING");

        return toDTO(orderRepository.save(entity));
    }

    // ── CANCEL ───────────────────────────────────────────────────────────

    @Override
    @Transactional
    public PosOrderDTO cancel(Long orderId, String reason) {
        PosOrder entity = findEntity(orderId);
        entity.setStatus("CANCELLED");
        entity.setRemarks(appendReason(entity.getRemarks(), reason));
        entity.setUpdatedAt(LocalDateTime.now());
        freeTableAfterOrder(entity, "AVAILABLE");
        return toDTO(orderRepository.save(entity));
    }

    // ── KITCHEN QUEUE ────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public List<Map<String, Object>> kitchenQueue() {
        Long orgId = SecurityHelper.requireOrgId();
        List<PosOrder> orders = orderRepository.findByOrganizationIdAndStatusInOrderByCreatedAtAsc(
                orgId, List.of("SENT_TO_KITCHEN", "READY"));

        List<Map<String, Object>> rows = new ArrayList<>();
        for (PosOrder order : orders) {
            for (PosOrderItem line : order.getItems()) {
                if (!KITCHEN_ACTIVE_STATUSES.contains(line.getKitchenStatus())) continue;
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("orderItemId", line.getId());
                row.put("orderId", order.getId());
                row.put("orderNo", order.getOrderNo());
                row.put("orderType", order.getOrderType());
                row.put("tableNo", order.getTable() != null ? order.getTable().getTableNo() : null);
                row.put("itemName", line.getItemNameSnapshot());
                row.put("qty", line.getQty());
                row.put("notes", line.getNotes());
                row.put("kitchenStatus", line.getKitchenStatus());
                row.put("createdAt", line.getCreatedAt() != null ? line.getCreatedAt().toString() : null);
                rows.add(row);
            }
        }
        return rows;
    }

    @Override
    @Transactional
    public PosOrderItemDTO updateItemKitchenStatus(Long orderItemId, String newStatus) {
        // Fetch through the parent order so we stay inside the aggregate and
        // can flip the order-level status when every line reaches READY/SERVED.
        for (PosOrder order : orderRepository.findByOrganizationIdAndStatusInOrderByCreatedAtAsc(
                SecurityHelper.requireOrgId(), List.of("SENT_TO_KITCHEN", "READY"))) {
            for (PosOrderItem line : order.getItems()) {
                if (line.getId().equals(orderItemId)) {
                    line.setKitchenStatus(newStatus);
                    line.setUpdatedAt(LocalDateTime.now());

                    boolean allReadyOrServed = order.getItems().stream()
                            .allMatch(li -> "READY".equals(li.getKitchenStatus()) || "SERVED".equals(li.getKitchenStatus()));
                    if (allReadyOrServed) {
                        order.setStatus("READY");
                        order.setUpdatedAt(LocalDateTime.now());
                    }
                    orderRepository.save(order);

                    return PosOrderItemDTO.builder()
                            .id(line.getId())
                            .menuItemId(line.getMenuItem() != null ? line.getMenuItem().getId() : null)
                            .itemName(line.getItemNameSnapshot())
                            .qty(line.getQty())
                            .unitPrice(line.getUnitPrice())
                            .lineTotal(line.getLineTotal())
                            .kitchenStatus(line.getKitchenStatus())
                            .notes(line.getNotes())
                            .build();
                }
            }
        }
        throw new IllegalArgumentException("Order item #" + orderItemId + " not found in an active order.");
    }

    // ── RECENT ORDERS ────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public List<PosOrderDTO> recentOrders(int limit) {
        Long orgId = SecurityHelper.requireOrgId();
        return orderRepository.findByOrganizationIdAndStatusInOrderByCreatedAtAsc(orgId,
                        List.of("OPEN", "SENT_TO_KITCHEN", "READY", "SERVED", "PAID", "CANCELLED"))
                .stream()
                .sorted(Comparator.comparing(PosOrder::getCreatedAt).reversed())
                .limit(Math.max(limit, 1))
                .map(this::toDTO)
                .toList();
    }

    // ── PRIVATE ──────────────────────────────────────────────────────────

    private PosOrder findEntity(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Order #" + id + " not found."));
    }

    private void recomputeTotal(PosOrder entity) {
        BigDecimal subtotal = entity.getSubtotal() != null ? entity.getSubtotal() : BigDecimal.ZERO;
        BigDecimal discount = entity.getDiscount() != null ? entity.getDiscount() : BigDecimal.ZERO;
        BigDecimal tax = entity.getTax() != null ? entity.getTax() : BigDecimal.ZERO;
        entity.setTotal(subtotal.subtract(discount).add(tax).max(BigDecimal.ZERO));
    }

    private void freeTableAfterOrder(PosOrder entity, String newStatus) {
        if (entity.getTable() == null) return;
        PosTable table = entity.getTable();
        table.setStatus(newStatus);
        table.setUpdatedAt(LocalDateTime.now());
        tableRepository.save(table);
    }

    private String appendReason(String remarks, String reason) {
        if (reason == null || reason.isBlank()) return remarks;
        String line = "Cancelled: " + reason;
        return (remarks == null || remarks.isBlank()) ? line : remarks + "\n" + line;
    }

    /** ★ See class-level note — replace with DocumentSequenceService if available. */
    private String nextOrderNo(Long orgId) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        long countToday = orderRepository.countByOrganizationIdAndCreatedAtBetween(orgId, start, end);
        String datePart = today.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        return String.format("POS-%s-%04d", datePart, countToday + 1);
    }

    private PosOrderDTO toDTO(PosOrder e) {
        return PosOrderDTO.builder()
                .id(e.getId())
                .organizationId(e.getOrganizationId())
                .orderNo(e.getOrderNo())
                .orderType(e.getOrderType())
                .tableId(e.getTable() != null ? e.getTable().getId() : null)
                .tableNo(e.getTable() != null ? e.getTable().getTableNo() : null)
                .customerName(e.getCustomerName())
                .customerPhone(e.getCustomerPhone())
                .status(e.getStatus())
                .subtotal(e.getSubtotal())
                .discount(e.getDiscount())
                .tax(e.getTax())
                .total(e.getTotal())
                .paymentMethod(e.getPaymentMethod())
                .remarks(e.getRemarks())
                .openedBy(e.getOpenedBy())
                .openedAt(e.getOpenedAt() != null ? e.getOpenedAt().toString() : null)
                .paidAt(e.getPaidAt() != null ? e.getPaidAt().toString() : null)
                .createdAt(e.getCreatedAt() != null ? e.getCreatedAt().toString() : null)
                .items(e.getItems().stream().map(line -> PosOrderItemDTO.builder()
                        .id(line.getId())
                        .menuItemId(line.getMenuItem() != null ? line.getMenuItem().getId() : null)
                        .itemName(line.getItemNameSnapshot())
                        .qty(line.getQty())
                        .unitPrice(line.getUnitPrice())
                        .lineTotal(line.getLineTotal())
                        .kitchenStatus(line.getKitchenStatus())
                        .notes(line.getNotes())
                        .build()).toList())
                .build();
    }
}
