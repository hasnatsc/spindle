package com.asg.spindleserp.pos.repository;

import com.asg.spindleserp.pos.entity.PosTable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PosTableRepository extends JpaRepository<PosTable, Long> {

    List<PosTable> findByOrganizationIdOrderByTableNoAsc(Long organizationId);

    boolean existsByOrganizationIdAndTableNoIgnoreCase(Long organizationId, String tableNo);
}
