package com.asg.spindleserp.pos.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "pos_table_bookings",
        indexes = {
                @Index(name = "idx_pos_tb_org", columnList = "organization_id"),
                @Index(name = "idx_pos_tb_table", columnList = "pos_table_id"),
                @Index(name = "idx_pos_tb_time", columnList = "booking_time")
        })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosTableBooking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "organization_id", nullable = false)
    private Long organizationId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pos_table_id")
    private PosTable table;

    @Column(name = "guest_name", nullable = false, length = 150)
    private String guestName;

    @Column(name = "guest_phone", nullable = false, length = 30)
    private String guestPhone;

    @Builder.Default
    @Column(name = "party_size")
    private Integer partySize = 2;

    @Column(name = "booking_time", nullable = false)
    private LocalDateTime bookingTime;

    /** BOOKED | SEATED | CANCELLED | NO_SHOW */
    @Builder.Default
    @Column(nullable = false, length = 20)
    private String status = "BOOKED";

    @Column(columnDefinition = "text")
    private String remarks;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
