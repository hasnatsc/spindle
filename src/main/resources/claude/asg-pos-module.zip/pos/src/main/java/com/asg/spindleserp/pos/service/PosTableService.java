package com.asg.spindleserp.pos.service;

import com.asg.spindleserp.pos.dto.PosTableBookingDTO;
import com.asg.spindleserp.pos.dto.PosTableDTO;
import com.asg.spindleserp.security.dto.DataTableResponse;

import java.util.List;

public interface PosTableService {

    // ── Tables (floor plan) ─────────────────────────────────────────────
    List<PosTableDTO> listTables();
    PosTableDTO saveTable(PosTableDTO dto);
    PosTableDTO updateTableStatus(Long id, String status);

    // ── Bookings ─────────────────────────────────────────────────────────
    DataTableResponse bookingsDatatable(int draw, int start, int length, String search, String date);
    PosTableBookingDTO saveBooking(PosTableBookingDTO dto);
    PosTableBookingDTO seatBooking(Long id);
    PosTableBookingDTO cancelBooking(Long id, String reason);
}
