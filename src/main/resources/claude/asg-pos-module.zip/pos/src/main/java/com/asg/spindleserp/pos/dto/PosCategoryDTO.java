package com.asg.spindleserp.pos.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosCategoryDTO {
    private Long id;
    private Long organizationId;
    private String name;
    private Integer sortOrder;
    private boolean active;
}
