package com.asg.spindleserp.pos.repository;

import com.asg.spindleserp.pos.entity.PosOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PosOrderRepository extends JpaRepository<PosOrder, Long> {

    Optional<PosOrder> findByOrganizationIdAndOrderNo(Long organizationId, String orderNo);

    /** Resume-in-progress lookup for the checkout screen's table picker. */
    Optional<PosOrder> findFirstByOrganizationIdAndTableIdAndStatusIn(
            Long organizationId, Long tableId, List<String> openStatuses);

    List<PosOrder> findByOrganizationIdAndStatusInOrderByCreatedAtAsc(Long organizationId, List<String> statuses);

    long countByOrganizationIdAndCreatedAtBetween(Long organizationId, LocalDateTime from, LocalDateTime to);
}
