package com.asg.spindleserp.pos.service;

import com.asg.spindleserp.pos.dto.PosOrderDTO;
import com.asg.spindleserp.pos.dto.PosOrderItemDTO;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface PosOrderService {

    PosOrderDTO findById(Long id);

    /** Resume-in-progress lookup used by the Checkout screen's table picker. */
    PosOrderDTO findOpenOrderForTable(Long tableId);

    /** Create (dto.id == null) or update (dto.id set) an order and its lines. */
    PosOrderDTO save(PosOrderDTO dto);

    PosOrderDTO sendToKitchen(Long orderId);

    PosOrderDTO checkout(Long orderId, String paymentMethod, BigDecimal discount, BigDecimal taxRate);

    PosOrderDTO cancel(Long orderId, String reason);

    /** Flattened order-item feed for the Kitchen Display screen, oldest first. */
    List<Map<String, Object>> kitchenQueue();

    PosOrderItemDTO updateItemKitchenStatus(Long orderItemId, String newStatus);

    List<PosOrderDTO> recentOrders(int limit);
}
