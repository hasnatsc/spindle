package com.asg.spindleserp.pos.controller;

import com.asg.spindleserp.pos.dto.PosOrderDTO;
import com.asg.spindleserp.pos.service.PosOrderService;
import com.asg.spindleserp.pos.service.PosTableService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PosCheckoutController — the Counter Checkout screen (/pos/checkout).
 *
 * REST:
 *   GET  /pos/tables/for-checkout            → open tables for the picker (delegates to PosTableService)
 *   GET  /pos/orders/open?tableId=           → resume an in-progress dine-in order
 *   GET  /pos/orders/show/{id}
 *   POST /pos/orders/save                    → create/replace cart lines
 *   POST /pos/orders/send-to-kitchen/{id}
 *   POST /pos/orders/checkout/{id}            body: { paymentMethod, discount, taxRate }
 *   POST /pos/orders/cancel/{id}              body: { reason }
 *   GET  /pos/orders/recent?length=8
 */
@Controller
@RequiredArgsConstructor
public class PosCheckoutController {

    private final PosOrderService posOrderService;
    private final PosTableService posTableService;

    @GetMapping("/pos/checkout")
    public String checkoutPage(Model model) {
        model.addAttribute("activePage", "pos-checkout");
        model.addAttribute("pageTitle", "Counter Checkout");
        return "pos/pos-checkout";
    }

    @GetMapping("/pos/tables/for-checkout")
    @ResponseBody
    public Map<String, Object> tablesForCheckout() {
        return Map.of("items", posTableService.listTables());
    }

    @GetMapping("/pos/orders/open")
    @ResponseBody
    public Map<String, Object> openForTable(@RequestParam Long tableId) {
        return ok(() -> Map.of("defaultData", posOrderService.findOpenOrderForTable(tableId)));
    }

    @GetMapping("/pos/orders/show/{id}")
    @ResponseBody
    public Map<String, Object> show(@PathVariable Long id) {
        return ok(() -> Map.of("defaultData", posOrderService.findById(id)));
    }

    @PostMapping("/pos/orders/save")
    @ResponseBody
    public Map<String, Object> save(@RequestBody @Valid PosOrderDTO dto) {
        return ok(() -> {
            PosOrderDTO saved = posOrderService.save(dto);
            return Map.of("defaultData", saved);
        });
    }

    @PostMapping("/pos/orders/send-to-kitchen/{id}")
    @ResponseBody
    public Map<String, Object> sendToKitchen(@PathVariable Long id) {
        return ok(() -> {
            PosOrderDTO order = posOrderService.sendToKitchen(id);
            return Map.of("defaultData", order);
        });
    }

    @PostMapping("/pos/orders/checkout/{id}")
    @ResponseBody
    public Map<String, Object> checkout(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        return ok(() -> {
            String paymentMethod = String.valueOf(body.get("paymentMethod"));
            BigDecimal discount = body.get("discount") != null ? new BigDecimal(String.valueOf(body.get("discount"))) : BigDecimal.ZERO;
            BigDecimal taxRate = body.get("taxRate") != null ? new BigDecimal(String.valueOf(body.get("taxRate"))) : BigDecimal.ZERO;
            PosOrderDTO order = posOrderService.checkout(id, paymentMethod, discount, taxRate);
            return Map.of("defaultData", order);
        });
    }

    @PostMapping("/pos/orders/cancel/{id}")
    @ResponseBody
    public Map<String, Object> cancel(@PathVariable Long id, @RequestBody(required = false) Map<String, Object> body) {
        return ok(() -> {
            String reason = body != null && body.get("reason") != null ? String.valueOf(body.get("reason")) : null;
            posOrderService.cancel(id, reason);
            return "Order cancelled.";
        });
    }

    @GetMapping("/pos/orders/recent")
    @ResponseBody
    public List<PosOrderDTO> recent(@RequestParam(defaultValue = "8") int length) {
        return posOrderService.recentOrders(length);
    }

    // ── Helper ───────────────────────────────────────────────────────────

    private Map<String, Object> ok(Checked action) {
        Map<String, Object> res = new HashMap<>();
        try {
            Object r = action.run();
            res.put("success", true);
            if (r instanceof String msg) res.put("message", msg);
            else if (r instanceof Map<?, ?> m) res.put("obj", m);
        } catch (Exception e) {
            res.put("success", false);
            res.put("message", e.getMessage());
        }
        return res;
    }

    @FunctionalInterface
    interface Checked { Object run() throws Exception; }
}
