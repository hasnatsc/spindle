/* ══════════════════════════════════════════════════════════════════════
   pos/pos-shell.js        /js/pos/pos-shell.js
   Shared helpers for all four POS screens — clock, fetch/CSRF, toasts,
   money formatting, XSS-safe escaping. Load this BEFORE the page-specific
   script. Exposes everything under window.PosShell.
   ══════════════════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  function startClock() {
    var el = document.getElementById('posClock');
    if (!el) return;
    var tick = function () {
      el.textContent = new Date().toLocaleTimeString('en-GB', { hour12: false });
    };
    tick();
    setInterval(tick, 1000);
  }

  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, function (ch) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch];
    });
  }

  function money(n) {
    var v = Number(n) || 0;
    return '\u09F3' + v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function warn(message) {
    if (typeof Swal !== 'undefined') {
      Swal.fire({ icon: 'warning', title: 'Check the form', text: message, confirmButtonColor: '#E8892B' });
    } else {
      alert(message);
    }
  }

  function confirmAction(opts) {
    opts = opts || {};
    if (typeof Swal !== 'undefined') {
      return Swal.fire({
        title: opts.title || 'Are you sure?',
        text: opts.text || '',
        icon: opts.icon || 'question',
        showCancelButton: true,
        confirmButtonColor: opts.confirmColor || '#E8892B',
        confirmButtonText: opts.confirmText || 'Confirm',
        cancelButtonText: 'Cancel'
      }).then(function (r) { return r.isConfirmed; });
    }
    return Promise.resolve(window.confirm(opts.text || opts.title || 'Are you sure?'));
  }

  function showMessage(containerId, message, success) {
    if (typeof hsAfterSaveMessages === 'function') {
      try { hsAfterSaveMessages(message, success, null, null, containerId); return; }
      catch (e) { /* fall through */ }
    }
    var box = document.getElementById(containerId);
    if (!box) {
      if (typeof Swal !== 'undefined') {
        Swal.fire({ icon: success ? 'success' : 'error', title: success ? 'Done' : 'Error', text: message, timer: success ? 1800 : undefined, showConfirmButton: !success });
      }
      return;
    }
    box.innerHTML = '<div class="alert ' + (success ? 'alert-success' : 'alert-danger') + ' alert-dismissible fade show" role="alert">' +
      esc(message) +
      '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
  }

  function fetchJson(url, options) {
    options = options || {};
    options.headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});

    if (typeof secureFetch === 'function') {
      return secureFetch(url, options).then(function (r) { return r.json(); });
    }

    var tokenMeta = document.querySelector('meta[name="_csrf"]');
    var headerMeta = document.querySelector('meta[name="_csrf_header"]');
    if (tokenMeta && headerMeta) {
      options.headers[headerMeta.content] = tokenMeta.content;
    }
    return fetch(url, options).then(function (r) { return r.json(); });
  }

  document.addEventListener('DOMContentLoaded', startClock);

  window.PosShell = { esc: esc, money: money, warn: warn, confirmAction: confirmAction, showMessage: showMessage, fetchJson: fetchJson };
})();
