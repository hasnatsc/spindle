package com.asg.spindleserp.pos.controller;

import com.asg.spindleserp.pos.dto.PosOrderItemDTO;
import com.asg.spindleserp.pos.service.PosOrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PosKitchenController — the Kitchen Order / KDS screen (/pos/kitchen).
 *
 * REST:
 *   GET  /pos/kitchen/queue                    → flattened active order-item feed
 *   POST /pos/kitchen/item-status/{orderItemId}  body: { status }
 *
 * The page polls /pos/kitchen/queue on an interval (see pos-kitchen.js) —
 * no websocket/SSE in this first pass, kept deliberately simple.
 */
@Controller
@RequiredArgsConstructor
public class PosKitchenController {

    private final PosOrderService posOrderService;

    @GetMapping("/pos/kitchen")
    public String kitchenPage(Model model) {
        model.addAttribute("activePage", "pos-kitchen");
        model.addAttribute("pageTitle", "Kitchen Order");
        return "pos/pos-kitchen";
    }

    @GetMapping("/pos/kitchen/queue")
    @ResponseBody
    public List<Map<String, Object>> queue() {
        return posOrderService.kitchenQueue();
    }

    @PostMapping("/pos/kitchen/item-status/{orderItemId}")
    @ResponseBody
    public Map<String, Object> itemStatus(@PathVariable Long orderItemId, @RequestBody Map<String, Object> body) {
        return ok(() -> {
            String status = String.valueOf(body.get("status"));
            PosOrderItemDTO updated = posOrderService.updateItemKitchenStatus(orderItemId, status);
            return Map.of("defaultData", updated);
        });
    }

    // ── Helper ───────────────────────────────────────────────────────────

    private Map<String, Object> ok(Checked action) {
        Map<String, Object> res = new HashMap<>();
        try {
            Object r = action.run();
            res.put("success", true);
            if (r instanceof String msg) res.put("message", msg);
            else if (r instanceof Map<?, ?> m) res.put("obj", m);
        } catch (Exception e) {
            res.put("success", false);
            res.put("message", e.getMessage());
        }
        return res;
    }

    @FunctionalInterface
    interface Checked { Object run() throws Exception; }
}
