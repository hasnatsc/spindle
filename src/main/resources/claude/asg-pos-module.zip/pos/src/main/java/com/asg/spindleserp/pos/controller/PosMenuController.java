package com.asg.spindleserp.pos.controller;

import com.asg.spindleserp.pos.dto.PosCategoryDTO;
import com.asg.spindleserp.pos.dto.PosMenuItemDTO;
import com.asg.spindleserp.pos.service.PosMenuService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PosMenuController — the Menu Stock screen (/pos/menu-stock).
 *
 * REST:
 *   GET  /pos/categories/list
 *   POST /pos/categories/save
 *   GET  /pos/menu-items/list?categoryId=&search=&onlyAvailable=
 *          → also used by the Checkout screen's item picker
 *   POST /pos/menu-items/save
 *   POST /pos/menu-items/stock/{id}          body: { qty }
 *   POST /pos/menu-items/adjust-stock/{id}   body: { delta }
 *   POST /pos/menu-items/availability/{id}
 *   DELETE /pos/menu-items/delete/{id}
 */
@Controller
@RequiredArgsConstructor
public class PosMenuController {

    private final PosMenuService posMenuService;

    @GetMapping("/pos/menu-stock")
    public String menuStockPage(Model model) {
        model.addAttribute("activePage", "pos-menu-stock");
        model.addAttribute("pageTitle", "Menu Stock");
        return "pos/pos-menu-stock";
    }

    // ── Categories ───────────────────────────────────────────────────────

    @GetMapping("/pos/categories/list")
    @ResponseBody
    public List<PosCategoryDTO> categoryList() {
        return posMenuService.listCategories();
    }

    @PostMapping("/pos/categories/save")
    @ResponseBody
    public Map<String, Object> categorySave(@RequestBody PosCategoryDTO dto) {
        return ok(() -> { posMenuService.saveCategory(dto); return "Category saved."; });
    }

    // ── Menu items ───────────────────────────────────────────────────────

    @GetMapping("/pos/menu-items/list")
    @ResponseBody
    public Map<String, Object> itemList(
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false, defaultValue = "") String search,
            @RequestParam(required = false, defaultValue = "false") boolean onlyAvailable) {
        return Map.of("items", posMenuService.listMenuItems(categoryId, search, onlyAvailable));
    }

    @GetMapping("/pos/menu-items/show/{id}")
    @ResponseBody
    public Map<String, Object> itemShow(@PathVariable Long id) {
        return ok(() -> Map.of("defaultData", posMenuService.findById(id)));
    }

    @PostMapping("/pos/menu-items/save")
    @ResponseBody
    public Map<String, Object> itemSave(@RequestBody @Valid PosMenuItemDTO dto) {
        return ok(() -> { posMenuService.save(dto); return "Menu item saved."; });
    }

    @PostMapping("/pos/menu-items/stock/{id}")
    @ResponseBody
    public Map<String, Object> stockSet(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        return ok(() -> {
            BigDecimal qty = new BigDecimal(String.valueOf(body.get("qty")));
            PosMenuItemDTO updated = posMenuService.updateStock(id, qty);
            return Map.of("defaultData", updated);
        });
    }

    @PostMapping("/pos/menu-items/adjust-stock/{id}")
    @ResponseBody
    public Map<String, Object> stockAdjust(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        return ok(() -> {
            BigDecimal delta = new BigDecimal(String.valueOf(body.get("delta")));
            PosMenuItemDTO updated = posMenuService.adjustStock(id, delta);
            return Map.of("defaultData", updated);
        });
    }

    @PostMapping("/pos/menu-items/availability/{id}")
    @ResponseBody
    public Map<String, Object> availabilityToggle(@PathVariable Long id) {
        return ok(() -> Map.of("defaultData", posMenuService.toggleAvailability(id)));
    }

    @DeleteMapping("/pos/menu-items/delete/{id}")
    @ResponseBody
    public Map<String, Object> itemDelete(@PathVariable Long id) {
        return ok(() -> { posMenuService.delete(id); return "Menu item deleted."; });
    }

    // ── Helper ───────────────────────────────────────────────────────────

    private Map<String, Object> ok(Checked action) {
        Map<String, Object> res = new HashMap<>();
        try {
            Object r = action.run();
            res.put("success", true);
            if (r instanceof String msg) res.put("message", msg);
            else if (r instanceof Map<?, ?> m) res.put("obj", m);
        } catch (Exception e) {
            res.put("success", false);
            res.put("message", e.getMessage());
        }
        return res;
    }

    @FunctionalInterface
    interface Checked { Object run() throws Exception; }
}
