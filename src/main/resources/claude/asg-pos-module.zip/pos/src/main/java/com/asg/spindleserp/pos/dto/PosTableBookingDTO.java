package com.asg.spindleserp.pos.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosTableBookingDTO {
    private Long id;
    private Long organizationId;
    private Long tableId;
    private String tableNo;
    private String guestName;
    private String guestPhone;
    private Integer partySize;
    private String bookingTime;     // ISO local date-time string from the form
    private String status;          // BOOKED | SEATED | CANCELLED | NO_SHOW
    private String remarks;
}
