package com.asg.spindleserp.pos.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "pos_tables",
        uniqueConstraints = @UniqueConstraint(name = "uq_pos_table_org_no", columnNames = {"organization_id", "table_no"}),
        indexes = @Index(name = "idx_pos_table_org", columnList = "organization_id"))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosTable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "organization_id", nullable = false)
    private Long organizationId;

    @Column(name = "table_no", nullable = false, length = 20)
    private String tableNo;

    @Column(length = 50)
    private String section;

    @Builder.Default
    @Column(nullable = false)
    private Integer capacity = 2;

    /** AVAILABLE | OCCUPIED | RESERVED | CLEANING */
    @Builder.Default
    @Column(nullable = false, length = 20)
    private String status = "AVAILABLE";

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
