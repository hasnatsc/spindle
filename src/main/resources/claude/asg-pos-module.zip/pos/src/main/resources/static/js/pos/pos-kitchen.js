/* pos/pos-kitchen.js — /js/pos/pos-kitchen.js   JS prefix: kd* */

(function () {
  'use strict';
  var Shell = window.PosShell;
  var POLL_MS = 10000;
  var NEXT_STATUS = { PENDING: 'PREPARING', PREPARING: 'READY', READY: 'SERVED' };
  var NEXT_LABEL  = { PENDING: 'Start preparing', PREPARING: 'Mark ready', READY: 'Mark served' };

  document.addEventListener('DOMContentLoaded', function () {
    kdLoadQueue();
    setInterval(kdLoadQueue, POLL_MS);
  });

  function kdLoadQueue() {
    Shell.fetchJson('/pos/kitchen/queue', { method: 'GET' })
      .then(function (rows) { renderColumns(rows || []); })
      .catch(function () { /* keep last known state on a transient failure */ });
  }

  function renderColumns(rows) {
    var byStatus = { PENDING: [], PREPARING: [], READY: [] };
    rows.forEach(function (r) { if (byStatus[r.kitchenStatus]) byStatus[r.kitchenStatus].push(r); });

    ['PENDING', 'PREPARING', 'READY'].forEach(function (status) {
      var col = document.getElementById('kdCol' + status);
      var count = document.getElementById('kdCount' + status);
      var list = byStatus[status];
      count.textContent = list.length;
      col.innerHTML = list.length
        ? list.map(renderTicket).join('')
        : '<div class="pos-empty">Nothing here.</div>';
    });
  }

  function renderTicket(row) {
    var typeLabel = row.orderType === 'DINE_IN' ? ('Table ' + Shell.esc(row.tableNo || '—')) : Shell.esc(row.orderType);
    var next = NEXT_STATUS[row.kitchenStatus];
    var btn = next
      ? '<button type="button" class="pos-btn pos-btn-primary pos-btn-sm" onclick="kdAdvance(' + row.orderItemId + ', \'' + next + '\')">' + NEXT_LABEL[row.kitchenStatus] + '</button>'
      : '';

    return '' +
      '<div class="kd-ticket">' +
        '<div class="kd-ticket-head">' +
          '<span class="kd-ticket-ref">' + Shell.esc(row.orderNo) + '</span>' +
          '<span class="pos-badge pos-badge-grey">' + typeLabel + '</span>' +
          '<span class="kd-ticket-elapsed">' + elapsed(row.createdAt) + '</span>' +
        '</div>' +
        '<div class="kd-ticket-item">' + Shell.esc(row.itemName) + ' <span class="kd-ticket-qty">×' + row.qty + '</span></div>' +
        (row.notes ? '<div class="kd-ticket-notes">' + Shell.esc(row.notes) + '</div>' : '') +
        '<div class="kd-ticket-actions">' + btn + '</div>' +
      '</div>';
  }

  function elapsed(createdAt) {
    if (!createdAt) return '';
    var mins = Math.max(0, Math.round((Date.now() - new Date(createdAt).getTime()) / 60000));
    return mins <= 0 ? 'just now' : (mins + 'm ago');
  }

  window.kdAdvance = function (orderItemId, nextStatus) {
    Shell.fetchJson('/pos/kitchen/item-status/' + orderItemId, { method: 'POST', body: JSON.stringify({ status: nextStatus }) })
      .then(function (res) {
        if (!res.success) throw new Error(res.message || 'Could not update this item.');
        kdLoadQueue();
      })
      .catch(function (err) { Shell.warn(err.message); });
  };
})();
