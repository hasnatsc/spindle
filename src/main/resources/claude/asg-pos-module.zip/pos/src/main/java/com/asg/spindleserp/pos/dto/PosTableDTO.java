package com.asg.spindleserp.pos.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PosTableDTO {
    private Long id;
    private Long organizationId;
    private String tableNo;
    private String section;
    private Integer capacity;
    private String status;          // AVAILABLE | OCCUPIED | RESERVED | CLEANING
    /** Populated only when listing tables for the floor plan, not persisted here. */
    private String currentOrderNo;
    private Long currentOrderId;
}
