/* pos/pos-menu-stock.js — /js/pos/pos-menu-stock.js   JS prefix: ms* */

(function () {
  'use strict';
  var Shell = window.PosShell;

  var state = { categoryId: '', search: '', onlyAvailable: false, categories: [] };
  var searchTimer = null;

  document.addEventListener('DOMContentLoaded', function () {
    msLoadCategories();
    msLoadItems();
  });

  // ── CATEGORIES ───────────────────────────────────────────────────────
  function msLoadCategories() {
    Shell.fetchJson('/pos/categories/list', { method: 'GET' })
      .then(function (cats) {
        state.categories = cats || [];
        renderTabs();
        renderCategorySelect();
      })
      .catch(function () { /* tabs just stay at "All" */ });
  }

  function renderTabs() {
    var wrap = document.getElementById('msCategoryTabs');
    var allTab = wrap.querySelector('[data-id=""]');
    wrap.innerHTML = '';
    wrap.appendChild(allTab);
    state.categories.forEach(function (c) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'pos-tab';
      btn.dataset.id = c.id;
      btn.textContent = c.name;
      btn.onclick = function () { window.msSelectCategory(btn); };
      wrap.appendChild(btn);
    });
  }

  function renderCategorySelect() {
    var sel = document.getElementById('msItemCategory');
    var current = sel.value;
    sel.innerHTML = '<option value="">Uncategorised</option>';
    state.categories.forEach(function (c) {
      var opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.name;
      sel.appendChild(opt);
    });
    sel.value = current;
  }

  window.msSelectCategory = function (el) {
    document.querySelectorAll('#msCategoryTabs .pos-tab').forEach(function (b) { b.classList.remove('active'); });
    el.classList.add('active');
    state.categoryId = el.dataset.id || '';
    msLoadItems();
  };

  window.msOpenCategoryModal = function () {
    document.getElementById('msCategoryName').value = '';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('msCategoryModal')).show();
  };

  window.msSaveCategory = function () {
    var name = document.getElementById('msCategoryName').value.trim();
    if (!name) { Shell.warn('Enter a category name.'); return; }
    Shell.fetchJson('/pos/categories/save', { method: 'POST', body: JSON.stringify({ name: name }) })
      .then(function (res) {
        if (!res.success) throw new Error(res.message || 'Could not save the category.');
        bootstrap.Modal.getOrCreateInstance(document.getElementById('msCategoryModal')).hide();
        Shell.showMessage('msMessages', 'Category saved.', true);
        msLoadCategories();
      })
      .catch(function (err) { Shell.warn(err.message); });
  };

  // ── ITEMS ────────────────────────────────────────────────────────────
  window.msDebouncedSearch = function () {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () {
      state.search = document.getElementById('msSearch').value;
      msLoadItems();
    }, 300);
  };

  window.msLoadItems = function () {
    state.onlyAvailable = document.getElementById('msOnlyAvailable').checked;
    var params = new URLSearchParams();
    if (state.categoryId) params.set('categoryId', state.categoryId);
    if (state.search) params.set('search', state.search);
    if (state.onlyAvailable) params.set('onlyAvailable', 'true');

    var grid = document.getElementById('msGrid');
    grid.innerHTML = '<div class="pos-empty">Loading menu…</div>';

    Shell.fetchJson('/pos/menu-items/list?' + params.toString(), { method: 'GET' })
      .then(function (res) {
        var items = (res && res.items) || [];
        if (!items.length) {
          grid.innerHTML = '<div class="pos-empty">No menu items match this filter.</div>';
          return;
        }
        grid.innerHTML = items.map(renderCard).join('');
      })
      .catch(function () {
        grid.innerHTML = '<div class="pos-empty">Couldn\u2019t load the menu. Try again.</div>';
      });
  };

  function renderCard(item) {
    var img = item.imageUrl
      ? '<div class="ms-item-img" style="background-image:url(\'' + Shell.esc(item.imageUrl) + '\')"></div>'
      : '<div class="ms-item-img"><i class="fa fa-utensils"></i></div>';
    var catBadge = item.categoryName ? '<span class="pos-badge pos-badge-amber ms-item-cat-badge">' + Shell.esc(item.categoryName) + '</span>' : '';

    return '' +
      '<div class="ms-item-card" data-id="' + item.id + '">' +
        img + catBadge +
        '<div class="ms-item-body">' +
          '<div class="ms-item-title">' + Shell.esc(item.itemName) + '</div>' +
          '<div class="ms-item-desc">' + Shell.esc(item.description || '') + '</div>' +
          '<div class="ms-item-price">' + Shell.money(item.unitPrice) + '</div>' +
          (item.trackStock ? '' +
            '<div class="ms-stock-row">' +
              '<button type="button" class="ms-stock-btn" onclick="msAdjustStock(' + item.id + ', -1)">−</button>' +
              '<input type="number" step="1" value="' + Number(item.stockQty) + '" onchange="msSetStock(' + item.id + ', this.value)"/>' +
              '<button type="button" class="ms-stock-btn" onclick="msAdjustStock(' + item.id + ', 1)">+</button>' +
            '</div>' : '<div class="ms-stock-row"><span class="pos-badge pos-badge-grey">Made to order</span></div>') +
          '<div class="ms-item-footer">' +
            '<label class="ms-avail-switch">' +
              '<input type="checkbox" ' + (item.available ? 'checked' : '') + ' onchange="msToggleAvailability(' + item.id + ')"/>' +
              '<span class="ms-avail-slider"></span>' +
            '</label>' +
            '<button type="button" class="ms-item-edit" onclick="msOpenItemModal(' + item.id + ')" title="Edit"><i class="fa-regular fa-pen-to-square"></i></button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  window.msSetStock = function (id, qty) {
    Shell.fetchJson('/pos/menu-items/stock/' + id, { method: 'POST', body: JSON.stringify({ qty: qty }) })
      .catch(function () { Shell.warn('Could not update stock.'); });
  };

  window.msAdjustStock = function (id, delta) {
    Shell.fetchJson('/pos/menu-items/adjust-stock/' + id, { method: 'POST', body: JSON.stringify({ delta: delta }) })
      .then(function () { msLoadItems(); })
      .catch(function () { Shell.warn('Could not update stock.'); });
  };

  window.msToggleAvailability = function (id) {
    Shell.fetchJson('/pos/menu-items/availability/' + id, { method: 'POST' })
      .catch(function () { Shell.warn('Could not update availability.'); });
  };

  // ── ITEM MODAL ───────────────────────────────────────────────────────
  window.msOpenItemModal = function (id) {
    var isEdit = !!id;
    document.getElementById('msItemModalTitle').textContent = isEdit ? 'Edit Menu Item' : 'New Menu Item';
    document.getElementById('msItemId').value = '';
    document.getElementById('msItemName').value = '';
    document.getElementById('msItemCode').value = '';
    document.getElementById('msItemDesc').value = '';
    document.getElementById('msItemPrice').value = '0';
    document.getElementById('msItemStock').value = '0';
    document.getElementById('msItemImage').value = '';
    document.getElementById('msItemTrackStock').checked = true;
    document.getElementById('msItemAvailable').checked = true;
    document.getElementById('msItemCategory').value = state.categoryId || '';

    var modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('msItemModal'));

    if (isEdit) {
      Shell.fetchJson('/pos/menu-items/show/' + id, { method: 'GET' }).then(function (res) {
        var item = res && res.obj && res.obj.defaultData;
        if (!item) return;
        document.getElementById('msItemId').value = item.id;
        document.getElementById('msItemName').value = item.itemName || '';
        document.getElementById('msItemCode').value = item.itemCode || '';
        document.getElementById('msItemDesc').value = item.description || '';
        document.getElementById('msItemPrice').value = item.unitPrice || 0;
        document.getElementById('msItemStock').value = item.stockQty || 0;
        document.getElementById('msItemImage').value = item.imageUrl || '';
        document.getElementById('msItemTrackStock').checked = !!item.trackStock;
        document.getElementById('msItemAvailable').checked = !!item.available;
        document.getElementById('msItemCategory').value = item.categoryId || '';
        modal.show();
      });
    } else {
      modal.show();
    }
  };

  window.msSaveItem = function () {
    var name = document.getElementById('msItemName').value.trim();
    if (!name) { Shell.warn('Enter an item name.'); return; }

    var dto = {
      id: document.getElementById('msItemId').value || null,
      itemName: name,
      itemCode: document.getElementById('msItemCode').value.trim() || null,
      description: document.getElementById('msItemDesc').value.trim(),
      unitPrice: parseFloat(document.getElementById('msItemPrice').value) || 0,
      stockQty: parseFloat(document.getElementById('msItemStock').value) || 0,
      imageUrl: document.getElementById('msItemImage').value.trim() || null,
      trackStock: document.getElementById('msItemTrackStock').checked,
      available: document.getElementById('msItemAvailable').checked,
      categoryId: document.getElementById('msItemCategory').value || null
    };

    Shell.fetchJson('/pos/menu-items/save', { method: 'POST', body: JSON.stringify(dto) })
      .then(function (res) {
        if (!res.success) throw new Error(res.message || 'Could not save the item.');
        bootstrap.Modal.getOrCreateInstance(document.getElementById('msItemModal')).hide();
        Shell.showMessage('msMessages', 'Menu item saved.', true);
        msLoadItems();
      })
      .catch(function (err) { Shell.warn(err.message); });
  };
})();
