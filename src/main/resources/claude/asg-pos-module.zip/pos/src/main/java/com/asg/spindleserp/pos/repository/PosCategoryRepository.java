package com.asg.spindleserp.pos.repository;

import com.asg.spindleserp.pos.entity.PosCategory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PosCategoryRepository extends JpaRepository<PosCategory, Long> {

    List<PosCategory> findByOrganizationIdAndActiveTrueOrderBySortOrderAscNameAsc(Long organizationId);

    boolean existsByOrganizationIdAndNameIgnoreCase(Long organizationId, String name);
}
