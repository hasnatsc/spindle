# ASG POS Module — Full Suite (Checkout · Kitchen · Table Booking · Menu Stock)

A complete, from-scratch POS module for Spindle ERP: 6 entities, 3 services,
4 controllers, a Flyway migration, and 4 fully wired front-end screens.
`ModuleKey.POS` / `Permission.Module.POS` already existed as a reserved slot
in your security layer with nothing built behind it — this fills that in.

Built as a standalone kiosk shell (own header/nav, no sidebar/topbar), the
same way Color Admin's own POS demo works and consistent with this project's
other bespoke full-screen pages (the control-tower style dashboards).

## What's a garment manufacturer doing with a restaurant POS?

Worth a beat before you wire this in: the most plausible real use of this
inside ASG Group is a **staff canteen / cafeteria counter**, not a public
restaurant — large RMG factories commonly run subsidized meal counters for
shift workers, and "Table Booking" maps naturally onto managing seating
across staggered lunch shifts rather than restaurant reservations. Nothing
in the code assumes one or the other (the language is generic: "guest",
"table", "order"), so it works either way — but if it's the canteen case,
you may want to rename a few UI labels ("Guest" → "Employee ID / Name",
"Table Booking" → "Shift Seating") and eventually gate checkout to a
payroll-deduction payment method instead of Cash/Card/Mobile.

## File map

```
src/main/java/com/asg/spindleserp/pos/
  entity/      PosCategory, PosMenuItem, PosTable, PosOrder, PosOrderItem, PosTableBooking
  dto/         one DTO per entity (+ nested PosOrderItemDTO on PosOrderDTO)
  repository/  Spring Data JPA repositories
  service/     PosMenuService, PosOrderService, PosTableService (+ Impl each)
  controller/  PosMenuController, PosCheckoutController, PosKitchenController, PosTableBookingController

src/main/resources/
  db/migration/V200__pos_module.sql
  templates/pos/     pos-shell.html (header fragment), pos-checkout.html, pos-kitchen.html,
                      pos-table-booking.html, pos-menu-stock.html
  static/css/pos/    pos-shell.css (shared tokens) + one CSS file per screen
  static/js/pos/     pos-shell.js (shared fetch/CSRF/toast helpers) + one JS file per screen
```

Drop the whole `src/` tree into your project root — paths match exactly.

## Integration steps

1. **Renumber the migration.** `V200__pos_module.sql` assumes nothing after
   V104 (the last version referenced in your Travel module notes) has been
   applied. Rename to your actual next Flyway version before running.
2. **Permissions.** `ModuleKey.POS` / `Permission.Module.POS` already exist;
   you'll still need `sec_permissions` rows + role grants for the new
   `/pos/**` URL patterns (`urlPattern`/`httpMethod` per endpoint) so
   `DynamicAuthorizationManager` lets users in. None of that is included
   here since it's data, not code — seed it the way you seed other modules'
   permissions.
3. **Static resource / security allow-list.** `/pos/**` templates render
   through normal authenticated routes (no `permitAll`), so no
   `SecurityConfig` changes should be needed beyond the permission rows
   above — but double check `/pos/**` isn't accidentally caught by an
   existing pattern.
4. **Fonts/icons.** Templates assume Font Awesome (`fa`/`far`) and Bootstrap
   5 modal JS are already global (they are, in your shell) — nothing extra
   to load beyond the two CSS/JS files each page links.

## ★ Deliberate simplifications (read before you rely on these)

- **Order numbering** (`PosOrderServiceImpl.nextOrderNo`) is a same-day
  `COUNT(*)`-based sequence — fine for one counter, not safe under heavy
  concurrent writes. Wire it to your existing `DocumentSequenceService`
  (`stp_document_sequences`) for the same guarantee every other document
  number in the ERP gets.
- **No GL/Accounts bridge.** `checkout()` marks the order `PAID` and stamps
  `paymentMethod`/`paidAt`, but does **not** create a `JournalEntryMaster`
  or touch `inv_items`. I didn't want to guess at your chart-of-accounts
  mapping and risk a wrong posting — this is the natural next step,
  following the same "confirm → auto-create POSTED JEM" pattern the rest
  of the app uses (see the Sales Invoice → Receipt Voucher bridge).
- **Stock lives entirely in `pos_menu_items.stock_qty`.** `linked_item_id`
  is a nullable, unenforced bridge column for if/when POS should draw from
  the shared Inventory ledger (`inv_items`) instead of its own counter.
- **Kitchen screen polls every 10s** (`pos-kitchen.js`) rather than using a
  websocket/SSE push — simplest thing that works for a first pass; swap in
  `SpringSessionBackedSessionRegistry`-style push infra later if the
  10-second lag matters for your kitchen.
- **No table double-booking check.** `PosTableServiceImpl` doesn't check
  for overlapping reservations on the same table/time slot — add one if a
  single floor has enough tables that staff can't just eyeball conflicts.
- **Checkout auto-saves the cart** on every add/remove/qty change (400ms
  debounce) rather than requiring an explicit "Save Draft" step, so a
  table's order survives a browser refresh and Send-to-Kitchen/Checkout
  always have a persisted `orderId` to act on.

## Endpoint reference

| Screen | Method | Path | Body |
|---|---|---|---|
| Menu Stock | GET | `/pos/categories/list` | — |
| | POST | `/pos/categories/save` | `{name, sortOrder?}` |
| | GET | `/pos/menu-items/list?categoryId=&search=&onlyAvailable=` | — |
| | POST | `/pos/menu-items/save` | `PosMenuItemDTO` |
| | POST | `/pos/menu-items/stock/{id}` | `{qty}` |
| | POST | `/pos/menu-items/adjust-stock/{id}` | `{delta}` |
| | POST | `/pos/menu-items/availability/{id}` | — |
| | DELETE | `/pos/menu-items/delete/{id}` | — |
| Checkout | GET | `/pos/tables/for-checkout` | — |
| | GET | `/pos/orders/open?tableId=` | — |
| | POST | `/pos/orders/save` | `PosOrderDTO` |
| | POST | `/pos/orders/send-to-kitchen/{id}` | — |
| | POST | `/pos/orders/checkout/{id}` | `{paymentMethod, discount, taxRate}` |
| | POST | `/pos/orders/cancel/{id}` | `{reason?}` |
| | GET | `/pos/orders/recent?length=8` | — |
| Kitchen | GET | `/pos/kitchen/queue` | — |
| | POST | `/pos/kitchen/item-status/{orderItemId}` | `{status}` |
| Table Booking | GET | `/pos/tables/list` | — |
| | POST | `/pos/tables/save` | `PosTableDTO` |
| | POST | `/pos/tables/status/{id}` | `{status}` |
| | GET | `/pos/table-bookings/list` | DataTables params + `date` |
| | POST | `/pos/table-bookings/save` | `PosTableBookingDTO` |
| | POST | `/pos/table-bookings/seat/{id}` | — |
| | POST | `/pos/table-bookings/cancel/{id}` | `{reason?}` |
